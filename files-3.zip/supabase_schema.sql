-- ═══════════════════════════════════════════════════════════════════════════
-- AFRICA-OS Ω — Supabase Schema
-- ═══════════════════════════════════════════════════════════════════════════
-- Creator: Dr. David King Boison
-- Run this in your Supabase SQL editor to initialise all tables.
-- ═══════════════════════════════════════════════════════════════════════════

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────────────────────────
-- SIGNALS
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signals (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id       TEXT        NOT NULL UNIQUE,
    signal_type     TEXT        NOT NULL,
    source_id       TEXT        NOT NULL,
    source_type     TEXT        NOT NULL DEFAULT 'formal_institution',
    sector          TEXT        NOT NULL,
    nation_id       TEXT        NOT NULL DEFAULT 'GH',
    payload         JSONB       NOT NULL DEFAULT '{}',
    freshness       FLOAT       DEFAULT 1.0,
    age_hours       FLOAT       DEFAULT 0.0,
    ttl_seconds     INTEGER,
    tags            TEXT[]      DEFAULT '{}',
    timestamp_utc   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_signals_sector       ON signals (sector);
CREATE INDEX idx_signals_nation       ON signals (nation_id);
CREATE INDEX idx_signals_signal_type  ON signals (signal_type);
CREATE INDEX idx_signals_created_at   ON signals (created_at DESC);
CREATE INDEX idx_signals_payload      ON signals USING GIN (payload);

-- ─────────────────────────────────────────────────────────────
-- TRAILS
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trails (
    id                   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    trail_id             TEXT        NOT NULL UNIQUE,
    objective            TEXT        NOT NULL,
    sector               TEXT        NOT NULL,
    nation_id            TEXT        NOT NULL DEFAULT 'GH',
    state                TEXT        NOT NULL DEFAULT 'provisional',
    confidence           FLOAT       NOT NULL DEFAULT 0.0,
    contradiction_count  INTEGER     NOT NULL DEFAULT 0,
    signal_refs          TEXT[]      DEFAULT '{}',
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_verified_at     TIMESTAMPTZ
);

CREATE INDEX idx_trails_sector    ON trails (sector);
CREATE INDEX idx_trails_state     ON trails (state);
CREATE INDEX idx_trails_nation    ON trails (nation_id);

-- ─────────────────────────────────────────────────────────────
-- DECISIONS
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS decisions (
    id                        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    decision_id               TEXT        NOT NULL UNIQUE,
    objective                 TEXT        NOT NULL,
    sector                    TEXT        NOT NULL,
    nation_id                 TEXT        NOT NULL DEFAULT 'GH',
    validation_state          TEXT        NOT NULL,
    confidence                FLOAT       NOT NULL,
    contradiction_count       INTEGER     NOT NULL DEFAULT 0,
    ecology_score             FLOAT       NOT NULL DEFAULT 0.0,
    inclusion_score           FLOAT       NOT NULL DEFAULT 0.0,
    hae_alignment_score       FLOAT       NOT NULL DEFAULT 0.0,
    recommended_action        JSONB       NOT NULL DEFAULT '{}',
    human_escalation_required BOOLEAN     NOT NULL DEFAULT FALSE,
    allowed_for_action        BOOLEAN     NOT NULL DEFAULT FALSE,
    local_fit_passed          BOOLEAN     NOT NULL DEFAULT TRUE,
    local_fit_report          JSONB       DEFAULT '{}',
    reasoning_summary         TEXT        DEFAULT '',
    audit_ref                 TEXT        NOT NULL,
    trail_id                  TEXT,
    requesting_role           TEXT        DEFAULT 'operator',
    created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_decisions_sector          ON decisions (sector);
CREATE INDEX idx_decisions_nation          ON decisions (nation_id);
CREATE INDEX idx_decisions_validation      ON decisions (validation_state);
CREATE INDEX idx_decisions_created_at      ON decisions (created_at DESC);
CREATE INDEX idx_decisions_audit_ref       ON decisions (audit_ref);
CREATE INDEX idx_decisions_escalation      ON decisions (human_escalation_required) WHERE human_escalation_required = TRUE;

-- ─────────────────────────────────────────────────────────────
-- ESCALATIONS
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS escalations (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    escalation_id   TEXT        NOT NULL UNIQUE,
    objective       TEXT        NOT NULL,
    sector          TEXT        NOT NULL,
    nation_id       TEXT        NOT NULL DEFAULT 'GH',
    priority        TEXT        NOT NULL DEFAULT 'MEDIUM',
    reason          TEXT        NOT NULL,
    source_ref      TEXT,
    decision_ref    TEXT,
    assigned_role   TEXT        NOT NULL DEFAULT 'sector_lead',
    queue_status    TEXT        NOT NULL DEFAULT 'pending',
    sla_minutes     INTEGER     NOT NULL DEFAULT 60,
    resolved_at     TIMESTAMPTZ,
    resolved_by     TEXT,
    resolution_note TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_escalations_sector      ON escalations (sector);
CREATE INDEX idx_escalations_priority    ON escalations (priority);
CREATE INDEX idx_escalations_status      ON escalations (queue_status);
CREATE INDEX idx_escalations_created_at  ON escalations (created_at DESC);

-- ─────────────────────────────────────────────────────────────
-- AUDIT LOG (immutable — no UPDATE or DELETE)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id                    UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    audit_ref             TEXT        NOT NULL UNIQUE,
    decision_id           TEXT,
    sector                TEXT        NOT NULL,
    nation_id             TEXT        NOT NULL DEFAULT 'GH',
    objective             TEXT        NOT NULL,
    signal_count          INTEGER     NOT NULL DEFAULT 0,
    validation_state      TEXT        NOT NULL,
    confidence            FLOAT       NOT NULL,
    contradiction_count   INTEGER     NOT NULL DEFAULT 0,
    ecology_score         FLOAT       NOT NULL DEFAULT 0.0,
    inclusion_score       FLOAT       NOT NULL DEFAULT 0.0,
    hae_alignment_score   FLOAT       NOT NULL DEFAULT 0.0,
    guardrail_events      TEXT[]      DEFAULT '{}',
    escalation_triggered  BOOLEAN     NOT NULL DEFAULT FALSE,
    reasoning_summary     TEXT        DEFAULT '',
    written_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_sector      ON audit_log (sector);
CREATE INDEX idx_audit_nation      ON audit_log (nation_id);
CREATE INDEX idx_audit_ref         ON audit_log (audit_ref);
CREATE INDEX idx_audit_decision    ON audit_log (decision_id);
CREATE INDEX idx_audit_created_at  ON audit_log (created_at DESC);

-- Immutability: revoke UPDATE and DELETE on audit_log
REVOKE UPDATE, DELETE ON audit_log FROM PUBLIC;

-- ─────────────────────────────────────────────────────────────
-- SECTOR HEALTH METRICS (24HAE Dashboard feed)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sector_health_metrics (
    id                    UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    sector                TEXT        NOT NULL,
    nation_id             TEXT        NOT NULL DEFAULT 'GH',
    metric_window         TEXT        NOT NULL DEFAULT '1h',
    avg_confidence        FLOAT       DEFAULT 0.0,
    avg_hae_score         FLOAT       DEFAULT 0.0,
    avg_ecology_score     FLOAT       DEFAULT 0.0,
    avg_inclusion_score   FLOAT       DEFAULT 0.0,
    decision_count        INTEGER     DEFAULT 0,
    escalation_count      INTEGER     DEFAULT 0,
    contradiction_rate    FLOAT       DEFAULT 0.0,
    trusted_ratio         FLOAT       DEFAULT 0.0,
    blocked_ratio         FLOAT       DEFAULT 0.0,
    computed_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_shm_sector      ON sector_health_metrics (sector);
CREATE INDEX idx_shm_nation      ON sector_health_metrics (nation_id);
CREATE INDEX idx_shm_computed_at ON sector_health_metrics (computed_at DESC);

-- ─────────────────────────────────────────────────────────────
-- ENTREPRENEUR SESSIONS (lightweight query log)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS entrepreneur_sessions (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id      TEXT        NOT NULL UNIQUE DEFAULT gen_random_uuid()::TEXT,
    sector          TEXT,
    nation_id       TEXT        NOT NULL DEFAULT 'GH',
    business_type   TEXT        DEFAULT 'MSME',
    query           TEXT,
    response        JSONB       DEFAULT '{}',
    decision_ref    TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ent_sector     ON entrepreneur_sessions (sector);
CREATE INDEX idx_ent_created_at ON entrepreneur_sessions (created_at DESC);

-- ─────────────────────────────────────────────────────────────
-- VIEWS — dashboard feeds
-- ─────────────────────────────────────────────────────────────

-- Active escalations view
CREATE OR REPLACE VIEW active_escalations AS
SELECT
    escalation_id, sector, nation_id, priority, reason,
    assigned_role, queue_status, sla_minutes,
    created_at,
    EXTRACT(EPOCH FROM (NOW() - created_at)) / 60 AS age_minutes,
    CASE
        WHEN EXTRACT(EPOCH FROM (NOW() - created_at)) / 60 > sla_minutes THEN TRUE
        ELSE FALSE
    END AS sla_breached
FROM escalations
WHERE queue_status = 'pending'
ORDER BY
    CASE priority WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END,
    created_at ASC;

-- 24-hour decision summary by sector
CREATE OR REPLACE VIEW decision_summary_24h AS
SELECT
    sector,
    nation_id,
    COUNT(*)                                                      AS total_decisions,
    ROUND(AVG(confidence)::NUMERIC, 3)                           AS avg_confidence,
    ROUND(AVG(hae_alignment_score)::NUMERIC, 3)                  AS avg_hae_score,
    ROUND(AVG(ecology_score)::NUMERIC, 3)                        AS avg_ecology_score,
    ROUND(AVG(inclusion_score)::NUMERIC, 3)                      AS avg_inclusion_score,
    SUM(CASE WHEN human_escalation_required THEN 1 ELSE 0 END)   AS escalation_count,
    SUM(CASE WHEN validation_state = 'trusted' THEN 1 ELSE 0 END) AS trusted_count,
    SUM(CASE WHEN validation_state = 'blocked' THEN 1 ELSE 0 END) AS blocked_count,
    ROUND(AVG(contradiction_count)::NUMERIC, 2)                  AS avg_contradictions
FROM decisions
WHERE created_at >= NOW() - INTERVAL '24 hours'
GROUP BY sector, nation_id
ORDER BY sector;

-- Continental signal health (last 1 hour)
CREATE OR REPLACE VIEW continental_signal_health AS
SELECT
    sector,
    nation_id,
    COUNT(*)                                                    AS signal_count,
    ROUND(AVG(freshness)::NUMERIC, 3)                          AS avg_freshness,
    MIN(freshness)                                              AS min_freshness,
    COUNT(CASE WHEN freshness < 0.30 THEN 1 END)               AS decayed_signals
FROM signals
WHERE created_at >= NOW() - INTERVAL '1 hour'
GROUP BY sector, nation_id
ORDER BY sector;

-- ─────────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY (enable for production)
-- ─────────────────────────────────────────────────────────────
ALTER TABLE signals              ENABLE ROW LEVEL SECURITY;
ALTER TABLE trails               ENABLE ROW LEVEL SECURITY;
ALTER TABLE decisions            ENABLE ROW LEVEL SECURITY;
ALTER TABLE escalations          ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log            ENABLE ROW LEVEL SECURITY;
ALTER TABLE sector_health_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE entrepreneur_sessions ENABLE ROW LEVEL SECURITY;

-- Service role bypass (for backend API)
CREATE POLICY "service_role_all" ON signals              FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON trails               FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON decisions            FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON escalations          FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON audit_log            FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON sector_health_metrics FOR ALL TO service_role USING (TRUE);
CREATE POLICY "service_role_all" ON entrepreneur_sessions FOR ALL TO service_role USING (TRUE);
