"""
AFRICA-OS Ω — Supabase Audit Store
=====================================
Drop-in replacement for the file-based AuditStore.
Persists signals, decisions, escalations, and audit entries
to Supabase PostgreSQL with full RLS support.

Usage:
    from core.supabase_store import SupabaseStore
    store = SupabaseStore(url=SUPABASE_URL, key=SUPABASE_SERVICE_KEY)
    # Pass as audit_store to ReasoningLoop

Creator: Dr. David King Boison
"""

import os
import httpx
import json
from datetime import datetime, timezone
from typing import Optional

from models.schemas import (
    AuditEntry, Signal, DecisionObject, EscalationItem
)


class SupabaseStore:
    """
    Supabase-backed persistent store for AFRICA-OS Ω.
    Uses the Supabase REST API (PostgREST) directly — no extra SDK needed.
    """

    def __init__(self, url: Optional[str] = None, key: Optional[str] = None):
        self.url = (url or os.getenv("SUPABASE_URL", "")).rstrip("/")
        self.key = key or os.getenv("SUPABASE_SERVICE_KEY", "")
        if not self.url or not self.key:
            raise ValueError(
                "SUPABASE_URL and SUPABASE_SERVICE_KEY must be set "
                "in environment or passed directly."
            )
        self.headers = {
            "apikey":        self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type":  "application/json",
            "Prefer":        "return=representation",
        }

    def _endpoint(self, table: str) -> str:
        return f"{self.url}/rest/v1/{table}"

    async def _insert(self, table: str, record: dict) -> dict:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                self._endpoint(table),
                headers=self.headers,
                content=json.dumps(record, default=str),
            )
            resp.raise_for_status()
            return resp.json()[0] if resp.text != "[]" else {}

    async def _select(self, table: str, filters: dict) -> list[dict]:
        params = {k: f"eq.{v}" for k, v in filters.items()}
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                self._endpoint(table),
                headers=self.headers,
                params=params,
            )
            resp.raise_for_status()
            return resp.json()

    # ─────────────────────────────────────────────────────────
    # SIGNALS
    # ─────────────────────────────────────────────────────────

    async def write_signal(self, signal: Signal) -> str:
        record = {
            "signal_id":     signal.signal_id,
            "signal_type":   signal.signal_type,
            "source_id":     signal.source_id,
            "source_type":   signal.source_type.value,
            "sector":        signal.sector.value,
            "nation_id":     signal.nation_id,
            "payload":       signal.payload,
            "freshness":     signal.freshness or 1.0,
            "age_hours":     signal.age_hours or 0.0,
            "ttl_seconds":   signal.ttl_seconds,
            "tags":          signal.tags,
            "timestamp_utc": signal.timestamp_utc.isoformat(),
        }
        await self._insert("signals", record)
        return signal.signal_id

    # ─────────────────────────────────────────────────────────
    # AUDIT (immutable append)
    # ─────────────────────────────────────────────────────────

    async def write(self, entry: AuditEntry) -> str:
        """Primary interface — matches AuditStore.write() signature."""
        record = {
            "audit_ref":            entry.audit_ref,
            "decision_id":          entry.decision_id,
            "sector":               entry.sector.value,
            "nation_id":            entry.nation_id,
            "objective":            entry.objective,
            "signal_count":         entry.signal_count,
            "validation_state":     entry.validation_state.value,
            "confidence":           entry.confidence,
            "contradiction_count":  entry.contradiction_count,
            "ecology_score":        entry.ecology_score,
            "inclusion_score":      entry.inclusion_score,
            "hae_alignment_score":  entry.hae_alignment_score,
            "guardrail_events":     entry.guardrail_events,
            "escalation_triggered": entry.escalation_triggered,
            "reasoning_summary":    entry.reasoning_summary,
            "written_at":           datetime.now(timezone.utc).isoformat(),
        }
        await self._insert("audit_log", record)
        return entry.audit_ref

    async def replay(self, audit_ref: str) -> Optional[dict]:
        results = await self._select("audit_log", {"audit_ref": audit_ref})
        return results[0] if results else None

    async def list_sector(self, sector: str, date: Optional[str] = None) -> list[dict]:
        return await self._select("audit_log", {"sector": sector})

    # ─────────────────────────────────────────────────────────
    # DECISIONS
    # ─────────────────────────────────────────────────────────

    async def write_decision(self, decision: DecisionObject) -> str:
        record = {
            "decision_id":               decision.decision_id,
            "objective":                 decision.objective,
            "sector":                    decision.sector.value,
            "nation_id":                 decision.nation_id,
            "validation_state":          decision.validation_state.value,
            "confidence":                decision.confidence,
            "contradiction_count":       decision.contradiction_count,
            "ecology_score":             decision.ecology_score,
            "inclusion_score":           decision.inclusion_score,
            "hae_alignment_score":       decision.hae_alignment_score,
            "recommended_action":        decision.recommended_action,
            "human_escalation_required": decision.human_escalation_required,
            "allowed_for_action":        decision.allowed_for_action,
            "local_fit_passed":          decision.local_fit_passed,
            "local_fit_report":          decision.local_fit_report.model_dump(),
            "reasoning_summary":         decision.reasoning_summary,
            "audit_ref":                 decision.audit_ref,
        }
        await self._insert("decisions", record)
        return decision.decision_id

    async def get_decision(self, decision_id: str) -> Optional[dict]:
        results = await self._select("decisions", {"decision_id": decision_id})
        return results[0] if results else None

    # ─────────────────────────────────────────────────────────
    # ESCALATIONS
    # ─────────────────────────────────────────────────────────

    async def write_escalation(self, esc: EscalationItem) -> str:
        record = {
            "escalation_id": esc.escalation_id,
            "objective":     esc.objective,
            "sector":        esc.sector.value,
            "nation_id":     esc.nation_id,
            "priority":      esc.priority.value,
            "reason":        esc.reason,
            "decision_ref":  esc.decision_ref,
            "assigned_role": esc.assigned_role.value,
            "queue_status":  esc.queue_status,
            "sla_minutes":   esc.sla_minutes,
        }
        await self._insert("escalations", record)
        return esc.escalation_id

    async def get_active_escalations(self, sector: Optional[str] = None) -> list[dict]:
        filters = {"queue_status": "pending"}
        if sector:
            filters["sector"] = sector
        return await self._select("escalations", filters)

    # ─────────────────────────────────────────────────────────
    # DASHBOARD FEEDS
    # ─────────────────────────────────────────────────────────

    async def get_sector_summary_24h(self) -> list[dict]:
        """Fetch the decision_summary_24h view for the situation room."""
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{self.url}/rest/v1/decision_summary_24h",
                headers=self.headers,
            )
            resp.raise_for_status()
            return resp.json()

    async def get_continental_signal_health(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{self.url}/rest/v1/continental_signal_health",
                headers=self.headers,
            )
            resp.raise_for_status()
            return resp.json()

    async def get_active_escalations_view(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{self.url}/rest/v1/active_escalations",
                headers=self.headers,
                params={"order": "created_at.asc", "limit": "50"},
            )
            resp.raise_for_status()
            return resp.json()
