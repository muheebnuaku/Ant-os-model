"""
AFRICA-OS Ω — Core Data Models
================================
Pydantic schemas for every object flowing through the reasoning loop:
Signal → Trail → Contradiction → Confidence → Decision → Audit

Creator: Dr. David King Boison
"""

from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field, field_validator
import uuid


# ─────────────────────────────────────────────────────────────
# ENUMERATIONS
# ─────────────────────────────────────────────────────────────

class Sector(str, Enum):
    HEALTH      = "health"
    AGRICULTURE = "agriculture"
    FINANCE     = "finance"
    ENERGY      = "energy"
    TRANSPORT   = "transport"
    EDUCATION   = "education"
    GOVERNANCE  = "governance"
    PORTS       = "ports"


class ValidationState(str, Enum):
    TRUSTED     = "trusted"
    PROVISIONAL = "provisional"
    CONFLICTED  = "conflicted"
    DECAYED     = "decayed"
    BLOCKED     = "blocked"


class EscalationPriority(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


class Role(str, Enum):
    CITIZEN_OBSERVER   = "citizen_observer"
    ENTREPRENEUR       = "entrepreneur"
    UNIVERSITY         = "university_researcher"
    OPERATOR           = "operator"
    ANALYST            = "analyst"
    SECTOR_LEAD        = "sector_lead"
    REGULATOR          = "regulator"
    ADMINISTRATOR      = "administrator"
    DEVELOPER          = "developer"
    SOVEREIGN_ADMIN    = "sovereign_admin"


class SourceType(str, Enum):
    FORMAL_INSTITUTION = "formal_institution"
    INFORMAL_OPERATOR  = "informal_operator"
    COMMUNITY_SOURCE   = "community_source"
    SATELLITE          = "satellite"
    API_FEED           = "api_feed"
    MANUAL_ENTRY       = "manual_entry"


class ContradictionSeverity(str, Enum):
    NONE     = "none"
    MINOR    = "minor"
    MODERATE = "moderate"
    SEVERE   = "severe"


class HaeState(str, Enum):
    ALIGNED    = "aligned"
    NEUTRAL    = "neutral"
    MISALIGNED = "misaligned"
    CRITICAL   = "critical"


class EisState(str, Enum):
    ACCEPTABLE = "acceptable"
    WARNING    = "warning"
    CRITICAL   = "critical"


# ─────────────────────────────────────────────────────────────
# SIGNAL
# ─────────────────────────────────────────────────────────────

class Signal(BaseModel):
    """
    The atomic unit of information entering AFRICA-OS Ω.
    Every piece of data — from a CHW field report to a GRIDCo
    SCADA reading — is normalised into a Signal before processing.
    """
    signal_id:     str           = Field(default_factory=lambda: f"SIG-{uuid.uuid4().hex[:10].upper()}")
    signal_type:   str
    source_id:     str
    source_type:   SourceType    = SourceType.FORMAL_INSTITUTION
    sector:        Sector
    nation_id:     str           = "GH"
    timestamp_utc: datetime      = Field(default_factory=lambda: datetime.now(timezone.utc))
    payload:       dict[str, Any]
    ttl_seconds:   Optional[int] = None
    tags:          list[str]     = Field(default_factory=list)
    # Computed at ingest
    freshness:     Optional[float] = None
    age_hours:     Optional[float] = None


class SignalIngestRequest(BaseModel):
    signal_type:   str
    source_id:     str
    source_type:   SourceType = SourceType.FORMAL_INSTITUTION
    sector:        Sector
    nation_id:     str        = "GH"
    payload:       dict[str, Any]
    ttl_seconds:   Optional[int] = None
    tags:          list[str]  = Field(default_factory=list)


class SignalIngestResponse(BaseModel):
    accepted:           bool
    signal_ref:         str
    freshness_at_ingest: float
    validation_note:    Optional[str] = None


# ─────────────────────────────────────────────────────────────
# CONFIDENCE
# ─────────────────────────────────────────────────────────────

class ConfidenceInput(BaseModel):
    """
    Inputs to the weighted multivariate confidence formula.
    C = (0.28*E) + (0.18*F) + (0.16*R) + (0.18*X) + (0.10*D) - (0.10*P)
    """
    sector:                    Sector
    nation_id:                 str   = "GH"
    evidence_strength:         float = Field(ge=0.0, le=1.0)
    signal_freshness:          float = Field(ge=0.0, le=1.0)
    source_reliability:        float = Field(ge=0.0, le=1.0, default=0.5)
    cross_signal_consistency:  float = Field(ge=0.0, le=1.0, default=0.5)
    domain_stability_modifier: float = Field(ge=0.0, le=1.0, default=0.5)
    contradiction_penalty:     float = Field(ge=0.0, le=1.0, default=0.0)


class ConfidenceResult(BaseModel):
    confidence:              float
    validation_state:        ValidationState
    domain_modifier_applied: float
    lambda_applied:          float
    computation_ref:         str = Field(default_factory=lambda: f"CONF-{uuid.uuid4().hex[:8].upper()}")


# ─────────────────────────────────────────────────────────────
# CONTRADICTION
# ─────────────────────────────────────────────────────────────

class ContradictionResult(BaseModel):
    contradiction_count:     int
    max_severity:            float
    severity_label:          ContradictionSeverity
    conflicted_signal_pairs: list[dict[str, Any]] = Field(default_factory=list)
    contradiction_penalty:   float
    recommended_action:      str


# ─────────────────────────────────────────────────────────────
# TRAIL
# ─────────────────────────────────────────────────────────────

class Trail(BaseModel):
    trail_id:           str = Field(default_factory=lambda: f"TRL-{uuid.uuid4().hex[:10].upper()}")
    objective:          str
    sector:             Sector
    nation_id:          str = "GH"
    signals:            list[Signal]
    state:              ValidationState = ValidationState.PROVISIONAL
    confidence:         float = 0.0
    contradiction_count: int  = 0
    created_at:         datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_verified_at:   Optional[datetime] = None


class TrailRequest(BaseModel):
    objective: str
    sector:    Sector
    nation_id: str = "GH"
    signals:   list[SignalIngestRequest]


class TrailResponse(BaseModel):
    trail_id:            str
    state:               ValidationState
    confidence:          float
    contradiction_count: int
    hae_continuity_score: float


# ─────────────────────────────────────────────────────────────
# ECOLOGY IMPACT SCORE
# ─────────────────────────────────────────────────────────────

class EnvironmentalImpact(BaseModel):
    carbon_emission_delta:        float = Field(ge=0.0, le=1.0, default=0.0)
    land_use_change_risk:         float = Field(ge=0.0, le=1.0, default=0.0)
    water_contamination_risk:     float = Field(ge=0.0, le=1.0, default=0.0)
    biodiversity_disruption_index: float = Field(ge=0.0, le=1.0, default=0.0)
    waste_generation_level:       float = Field(ge=0.0, le=1.0, default=0.0)


class SocialImpact(BaseModel):
    community_displacement_risk:  float = Field(ge=0.0, le=1.0, default=0.0)
    health_risk_to_population:    float = Field(ge=0.0, le=1.0, default=0.0)
    equity_impact_score:          float = Field(ge=0.0, le=1.0, default=0.0)
    cultural_heritage_risk:       float = Field(ge=0.0, le=1.0, default=0.0)
    livelihood_disruption_index:  float = Field(ge=0.0, le=1.0, default=0.0)


class ResourceStress(BaseModel):
    water_extraction_rate:        float = Field(ge=0.0, le=1.0, default=0.0)
    energy_demand_stress:         float = Field(ge=0.0, le=1.0, default=0.0)
    soil_degradation_index:       float = Field(ge=0.0, le=1.0, default=0.0)
    infrastructure_load_factor:   float = Field(ge=0.0, le=1.0, default=0.0)
    raw_material_depletion_risk:  float = Field(ge=0.0, le=1.0, default=0.0)


class EcologyInput(BaseModel):
    sector:               Sector
    nation_id:            str    = "GH"
    decision_ref:         Optional[str] = None
    environmental_impact: EnvironmentalImpact = Field(default_factory=EnvironmentalImpact)
    social_impact:        SocialImpact        = Field(default_factory=SocialImpact)
    resource_stress:      ResourceStress      = Field(default_factory=ResourceStress)


class EcologyResult(BaseModel):
    eis_score:                  float
    eis_state:                  EisState
    environmental_impact_score: float
    social_impact_score:        float
    resource_stress_score:      float
    enforcement_action:         str
    audit_ref:                  str = Field(default_factory=lambda: f"EIS-{uuid.uuid4().hex[:8].upper()}")


# ─────────────────────────────────────────────────────────────
# INCLUSION
# ─────────────────────────────────────────────────────────────

class InclusionInput(BaseModel):
    sector:                  Sector
    nation_id:               str   = "GH"
    decision_ref:            Optional[str] = None
    informal_economy_reach:  float = Field(ge=0.0, le=1.0, default=0.5)
    rural_reach:             float = Field(ge=0.0, le=1.0, default=0.5)
    gender_equity_score:     float = Field(ge=0.0, le=1.0, default=0.5)
    youth_inclusion_score:   float = Field(ge=0.0, le=1.0, default=0.5)
    disability_inclusion_score: float = Field(ge=0.0, le=1.0, default=0.5)


class InclusionResult(BaseModel):
    inclusion_score:         float
    inclusion_state:         str
    flagged_dimensions:      list[str] = Field(default_factory=list)
    recommended_adjustments: list[str] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# 24-HOUR AFRICA ECONOMY ALIGNMENT
# ─────────────────────────────────────────────────────────────

class HaeInput(BaseModel):
    sector:                       Sector
    nation_id:                    str   = "GH"
    decision_ref:                 Optional[str] = None
    productive_capacity_impact:   float = Field(ge=-1.0, le=1.0, default=0.0,
                                                description="Negative=reduces, Positive=increases")
    intra_african_value_creation: bool  = False
    informal_actor_inclusion:     bool  = False
    worker_dignity_preserved:     bool  = True
    dependency_reduction:         bool  = False


class HaeResult(BaseModel):
    hae_alignment_score: float
    hae_state:           HaeState
    policy_flags:        list[str] = Field(default_factory=list)
    recommended_adjustments: list[str] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# LOCAL FIT TEST
# ─────────────────────────────────────────────────────────────

class LocalFitResult(BaseModel):
    local_fit_passed:        bool
    overall_score:           float
    dimensions_evaluated:    int
    dimensions_passed:       int
    dimensions_failed:       list[str] = Field(default_factory=list)
    hard_fail_triggered:     bool      = False
    escalation_triggered:    bool      = False
    recommended_remediation: list[str] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# DECISION
# ─────────────────────────────────────────────────────────────

class DecisionRequest(BaseModel):
    objective:          str
    sector:             Sector
    nation_id:          str  = "GH"
    signals:            list[SignalIngestRequest]
    high_consequence:   bool = False
    ecology_context:    Optional[EcologyInput]   = None
    inclusion_context:  Optional[InclusionInput] = None
    hae_context:        Optional[HaeInput]       = None
    requesting_role:    Role = Role.OPERATOR


class DecisionObject(BaseModel):
    decision_id:              str = Field(default_factory=lambda: f"DEC-{uuid.uuid4().hex[:12].upper()}")
    objective:                str
    sector:                   Sector
    nation_id:                str
    validation_state:         ValidationState
    confidence:               float
    contradiction_count:      int
    ecology_score:            float
    inclusion_score:          float
    hae_alignment_score:      float
    recommended_action:       dict[str, Any]
    human_escalation_required: bool
    allowed_for_action:       bool
    local_fit_passed:         bool
    local_fit_report:         LocalFitResult
    reasoning_summary:        str
    audit_ref:                str
    created_at:               datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ─────────────────────────────────────────────────────────────
# ESCALATION
# ─────────────────────────────────────────────────────────────

class EscalationItem(BaseModel):
    escalation_id:    str = Field(default_factory=lambda: f"ESC-{uuid.uuid4().hex[:10].upper()}")
    objective:        str
    sector:           Sector
    nation_id:        str
    priority:         EscalationPriority
    reason:           str
    source_ref:       Optional[str] = None
    decision_ref:     Optional[str] = None
    assigned_role:    Role
    queue_status:     str     = "pending"
    sla_minutes:      int     = 60
    created_at:       datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ─────────────────────────────────────────────────────────────
# AUDIT
# ─────────────────────────────────────────────────────────────

class AuditEntry(BaseModel):
    audit_ref:         str = Field(default_factory=lambda: f"AUD-{uuid.uuid4().hex[:12].upper()}")
    decision_id:       Optional[str] = None
    sector:            Sector
    nation_id:         str
    objective:         str
    signal_count:      int
    validation_state:  ValidationState
    confidence:        float
    contradiction_count: int
    ecology_score:     float
    inclusion_score:   float
    hae_alignment_score: float
    guardrail_events:  list[str] = Field(default_factory=list)
    escalation_triggered: bool   = False
    reasoning_summary: str       = ""
    created_at:        datetime  = Field(default_factory=lambda: datetime.now(timezone.utc))
