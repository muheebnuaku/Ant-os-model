"""
AFRICA-OS Ω — Sector Pack Configuration
=========================================
Domain-specific calibration for all 8 core sectors.
Each pack defines lambda decay, confidence modifiers,
contradiction tolerances, and ecology metric priorities.

Creator: Dr. David King Boison
"""

from dataclasses import dataclass, field
from typing import Optional
from models.schemas import Sector


@dataclass
class ConfidenceWeightOverride:
    evidence_strength:         float = 0.28
    signal_freshness:          float = 0.18
    source_reliability:        float = 0.16
    cross_signal_consistency:  float = 0.18
    domain_stability_modifier: float = 0.10
    contradiction_penalty:     float = 0.10


@dataclass
class SectorPack:
    sector_id:              Sector
    sector_name:            str
    domain_label:           str
    priority_24hae:         str
    lambda_override:        float
    half_life_hours:        float
    domain_modifier:        float
    confidence_threshold_trusted:     float = 0.85
    confidence_threshold_provisional: float = 0.60
    confidence_threshold_conflicted:  float = 0.30
    weight_overrides:       ConfidenceWeightOverride = field(default_factory=ConfidenceWeightOverride)
    contradiction_tolerances: dict = field(default_factory=dict)
    ecology_active_metrics: list  = field(default_factory=list)
    eis_warning_threshold:  float = 0.50
    eis_critical_threshold: float = 0.75
    escalation_rules:       list  = field(default_factory=list)
    jurisdiction_laws:      list  = field(default_factory=list)
    infrastructure_profile: str   = "intermittent_connectivity"


# ─────────────────────────────────────────────────────────────
# SECTOR PACK REGISTRY
# ─────────────────────────────────────────────────────────────

SECTOR_PACKS: dict[Sector, SectorPack] = {

    Sector.HEALTH: SectorPack(
        sector_id=Sector.HEALTH,
        sector_name="Health Sector",
        domain_label="health",
        priority_24hae="CRITICAL",
        lambda_override=0.693,
        half_life_hours=1.0,
        domain_modifier=1.10,
        confidence_threshold_trusted=0.88,
        weight_overrides=ConfidenceWeightOverride(
            evidence_strength=0.30,
            signal_freshness=0.22,
            source_reliability=0.14,
            cross_signal_consistency=0.18,
            domain_stability_modifier=0.08,
            contradiction_penalty=0.08,
        ),
        contradiction_tolerances={
            "bed_capacity_signal":      0.08,
            "triage_status_signal":     0.07,
            "drug_stock_level":         0.12,
            "disease_outbreak_signal":  0.05,
            "maternal_mortality_rate":  0.10,
            "default":                  0.10,
        },
        ecology_active_metrics=[
            "health_risk_to_population",
            "waste_generation_level",
            "water_contamination_risk",
        ],
        eis_critical_threshold=0.70,
        escalation_rules=[
            {"trigger": "bed_capacity < 0.10 AND outbreak_confirmed", "priority": "CRITICAL", "sla_minutes": 15},
            {"trigger": "drug_stock < safety_threshold",               "priority": "HIGH",     "sla_minutes": 30},
            {"trigger": "contradiction_severity == severe",             "priority": "CRITICAL", "sla_minutes": 15},
        ],
        jurisdiction_laws=[
            "Public Health Act 2012 (Act 851) — Ghana",
            "Health Facilities Regulatory Act — Ghana",
            "National Health Insurance Act 2003 (Act 650) — Ghana",
        ],
        infrastructure_profile="intermittent_connectivity",
    ),

    Sector.AGRICULTURE: SectorPack(
        sector_id=Sector.AGRICULTURE,
        sector_name="Agriculture and Food Systems Sector",
        domain_label="agriculture",
        priority_24hae="CRITICAL",
        lambda_override=0.0347,
        half_life_hours=20.0,
        domain_modifier=0.95,
        confidence_threshold_trusted=0.82,
        weight_overrides=ConfidenceWeightOverride(
            evidence_strength=0.26,
            signal_freshness=0.16,
            source_reliability=0.16,
            cross_signal_consistency=0.20,
            domain_stability_modifier=0.12,
            contradiction_penalty=0.10,
        ),
        contradiction_tolerances={
            "farmgate_price_signal":   0.25,
            "crop_yield_forecast":     0.30,
            "input_availability":      0.20,
            "weather_signal":          0.15,
            "soil_moisture":           0.20,
            "default":                 0.22,
        },
        ecology_active_metrics=[
            "soil_degradation_index",
            "water_extraction_rate",
            "biodiversity_disruption_index",
            "land_use_change_risk",
        ],
        eis_warning_threshold=0.45,
        eis_critical_threshold=0.70,
        jurisdiction_laws=[
            "Agriculture Mechanization Act — Ghana",
            "Plant and Fertilizer Act 2010 — Ghana",
        ],
        infrastructure_profile="intermittent_connectivity",
    ),

    Sector.FINANCE: SectorPack(
        sector_id=Sector.FINANCE,
        sector_name="Finance, Banking and Capital Markets Sector",
        domain_label="finance",
        priority_24hae="CRITICAL",
        lambda_override=0.347,
        half_life_hours=2.0,
        domain_modifier=1.20,
        confidence_threshold_trusted=0.88,
        confidence_threshold_conflicted=0.35,
        weight_overrides=ConfidenceWeightOverride(
            evidence_strength=0.30,
            signal_freshness=0.20,
            source_reliability=0.16,
            cross_signal_consistency=0.18,
            domain_stability_modifier=0.08,
            contradiction_penalty=0.08,
        ),
        contradiction_tolerances={
            "liquidity_signal":              0.06,
            "exchange_rate_signal":          0.05,
            "mobile_money_transaction":      0.08,
            "credit_risk_signal":            0.10,
            "capital_adequacy_signal":       0.08,
            "default":                       0.08,
        },
        ecology_active_metrics=["equity_impact_score", "community_displacement_risk"],
        jurisdiction_laws=[
            "Banks and Specialised Deposit-Taking Institutions Act 2016 (Act 930) — Ghana",
            "Payment Systems and Services Act 2019 (Act 987) — Ghana",
        ],
        infrastructure_profile="full_connectivity",
    ),

    Sector.ENERGY: SectorPack(
        sector_id=Sector.ENERGY,
        sector_name="Energy and Power Sector",
        domain_label="energy",
        priority_24hae="CRITICAL",
        lambda_override=0.231,
        half_life_hours=3.0,
        domain_modifier=1.15,
        confidence_threshold_trusted=0.86,
        weight_overrides=ConfidenceWeightOverride(
            evidence_strength=0.28,
            signal_freshness=0.22,
            source_reliability=0.16,
            cross_signal_consistency=0.18,
            domain_stability_modifier=0.08,
            contradiction_penalty=0.08,
        ),
        contradiction_tolerances={
            "grid_load_signal":          0.08,
            "generation_capacity":       0.10,
            "fuel_stock_signal":         0.10,
            "power_outage_signal":       0.05,
            "renewable_generation":      0.12,
            "default":                   0.09,
        },
        ecology_active_metrics=[
            "carbon_emission_delta",
            "energy_demand_stress",
            "infrastructure_load_factor",
            "land_use_change_risk",
        ],
        jurisdiction_laws=[
            "Energy Commission Act 1997 (Act 541) — Ghana",
            "Renewable Energy Act 2011 (Act 832) — Ghana",
        ],
        infrastructure_profile="full_connectivity",
    ),

    Sector.TRANSPORT: SectorPack(
        sector_id=Sector.TRANSPORT,
        sector_name="Transport and Logistics Sector",
        domain_label="transport",
        priority_24hae="HIGH",
        lambda_override=0.139,
        half_life_hours=5.0,
        domain_modifier=1.00,
        confidence_threshold_trusted=0.82,
        contradiction_tolerances={
            "road_condition_signal":    0.20,
            "corridor_status":          0.18,
            "fleet_availability":       0.20,
            "border_crossing":          0.15,
            "logistics_cost":           0.25,
            "default":                  0.20,
        },
        ecology_active_metrics=[
            "carbon_emission_delta",
            "infrastructure_load_factor",
            "health_risk_to_population",
        ],
        jurisdiction_laws=[
            "Roads Act 1997 (Act 536) — Ghana",
            "Road Traffic Act 2004 (Act 683) — Ghana",
        ],
        infrastructure_profile="intermittent_connectivity",
    ),

    Sector.EDUCATION: SectorPack(
        sector_id=Sector.EDUCATION,
        sector_name="Education, Research and Human Capital Sector",
        domain_label="education",
        priority_24hae="HIGH",
        lambda_override=0.0198,
        half_life_hours=35.0,
        domain_modifier=1.00,
        confidence_threshold_trusted=0.80,
        contradiction_tolerances={
            "enrollment_signal":        0.15,
            "teacher_availability":     0.20,
            "graduate_employment":      0.25,
            "research_output":          0.30,
            "default":                  0.22,
        },
        ecology_active_metrics=["equity_impact_score", "community_displacement_risk"],
        jurisdiction_laws=[
            "Education Act 1961 (Act 87) — Ghana",
            "TVET Policy — Ghana",
        ],
        infrastructure_profile="intermittent_connectivity",
    ),

    Sector.GOVERNANCE: SectorPack(
        sector_id=Sector.GOVERNANCE,
        sector_name="Governance, Public Administration and Rule of Law",
        domain_label="governance",
        priority_24hae="HIGH",
        lambda_override=0.0198,
        half_life_hours=35.0,
        domain_modifier=1.05,
        confidence_threshold_trusted=0.85,
        contradiction_tolerances={
            "policy_signal":            0.10,
            "budget_execution":         0.12,
            "service_delivery":         0.15,
            "corruption_risk":          0.08,
            "electoral_signal":         0.05,
            "default":                  0.10,
        },
        ecology_active_metrics=[
            "community_displacement_risk",
            "equity_impact_score",
            "cultural_heritage_risk",
        ],
        jurisdiction_laws=[
            "Constitution of Ghana 1992",
            "Local Governance Act 2016 (Act 936) — Ghana",
            "Public Financial Management Act 2016 (Act 921) — Ghana",
        ],
        infrastructure_profile="full_connectivity",
    ),

    Sector.PORTS: SectorPack(
        sector_id=Sector.PORTS,
        sector_name="Ports, Maritime and Trade Facilitation Sector",
        domain_label="ports",
        priority_24hae="HIGH",
        lambda_override=0.099,
        half_life_hours=7.0,
        domain_modifier=1.00,
        confidence_threshold_trusted=0.85,
        contradiction_tolerances={
            "vessel_arrival_eta":       0.12,
            "berth_occupancy":          0.08,
            "container_manifest":       0.05,
            "customs_clearance":        0.10,
            "demurrage_signal":         0.15,
            "default":                  0.10,
        },
        ecology_active_metrics=[
            "carbon_emission_delta",
            "water_contamination_risk",
            "infrastructure_load_factor",
            "waste_generation_level",
        ],
        eis_warning_threshold=0.55,
        eis_critical_threshold=0.78,
        jurisdiction_laws=[
            "Ghana Ports and Harbours Authority Act 1986 (PNDC Law 160) — Ghana",
            "Customs Act 2015 (Act 891) — Ghana",
        ],
        infrastructure_profile="full_connectivity",
    ),
}


def get_sector_pack(sector: Sector) -> SectorPack:
    """Retrieve the configured sector pack for a given sector."""
    pack = SECTOR_PACKS.get(sector)
    if not pack:
        raise ValueError(f"No sector pack registered for sector: {sector}")
    return pack
