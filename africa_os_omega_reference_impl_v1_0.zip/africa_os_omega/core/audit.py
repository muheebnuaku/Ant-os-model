"""
AFRICA-OS Ω — Audit Store
===========================
File-based audit store for development and testing.
Drop-in replacement interface for PostgreSQL in production.

Creator: Dr. David King Boison
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from models.schemas import AuditEntry


class AuditStore:
    """
    Append-only audit store. Every reasoning decision writes an immutable entry.
    File-based for development. Replace _write_to_backend() for PostgreSQL.
    """

    def __init__(self, log_path: str = "./audit_logs"):
        self.log_path = Path(log_path)
        self.log_path.mkdir(parents=True, exist_ok=True)

    async def write(self, entry: AuditEntry) -> str:
        """Write an audit entry. Returns the audit_ref."""
        record = entry.model_dump(mode="json")
        record["written_at"] = datetime.now(timezone.utc).isoformat()

        date_str  = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_file  = self.log_path / f"audit_{entry.sector.value}_{date_str}.jsonl"

        with open(log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")

        return entry.audit_ref

    async def replay(self, audit_ref: str) -> dict | None:
        """Retrieve a specific audit entry by ref."""
        for log_file in self.log_path.glob("*.jsonl"):
            with open(log_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line)
                        if record.get("audit_ref") == audit_ref:
                            return record
                    except json.JSONDecodeError:
                        continue
        return None

    async def list_sector(self, sector: str, date: str | None = None) -> list[dict]:
        """List audit entries for a sector, optionally filtered by date."""
        results = []
        pattern = f"audit_{sector}_{date}.jsonl" if date else f"audit_{sector}_*.jsonl"
        for log_file in self.log_path.glob(pattern):
            with open(log_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        results.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return sorted(results, key=lambda x: x.get("created_at", ""), reverse=True)
