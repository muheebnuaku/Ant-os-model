"""
AFRICA-OS Ω — Core Reasoning Loop
=====================================
Orchestrates the full 19-step signal → decision chain.

Reasoning Contract:
  1.  ingest_signal
  2.  classify_signal_and_sector
  3.  attach_provenance_and_timestamp
  4.  evaluate_freshness_with_domain_lambda
  5.  evaluate_source_reliability
  6.  attach_or_create_trail
  7.  detect_contradictions_and_assign_severity
  8.  compute_confidence_score
  9.  assign_validation_state
  10. run_inclusion_check
  11. run_policy_precheck_24hae
  12. run_ecology_check_EIS
  13. evaluate_intra_african_trade_alignment
  14. reason_over_options_with_ubuntu_lens
  15. generate_decision_object
  16. run_policy_postcheck
  17. run_local_fit_test
  18. create_audit_ref
  19. return_or_escalate

Creator: Dr. David King Boison
"""

import uuid
import math
import json
from datetime import datetime, timezone
from typing import Optional
import httpx

from models.schemas import (
    Signal, SignalIngestRequest, Trail, DecisionRequest, DecisionObject,
    ConfidenceInput, EcologyInput, InclusionInput, HaeInput, LocalFitResult,
    ValidationState, EscalationItem, EscalationPriority, AuditEntry,
    Role, Sector, EnvironmentalImpact, SocialImpact, ResourceStress,
)
from engines.reasoning_engines import (
    ConfidenceEngine, ContradictionEngine, EcologyEngine,
    InclusionEngine, HaeEngine, LocalFitEngine,
)
from core.sector_packs import get_sector_pack
from core.audit import AuditStore


class ReasoningLoop:
    """
    The sovereign reasoning core of AFRICA-OS Ω.
    Executes the full 19-step reasoning contract for every decision request.
    """

    def __init__(self, audit_store: AuditStore, llm_client: Optional[object] = None):
        self.audit = audit_store
        self.llm   = llm_client
        self.confidence_engine   = ConfidenceEngine()
        self.contradiction_engine = ContradictionEngine()
        self.ecology_engine      = EcologyEngine()
        self.inclusion_engine    = InclusionEngine()
        self.hae_engine          = HaeEngine()
        self.local_fit_engine    = LocalFitEngine()

    # ─────────────────────────────────────────────────────────
    # STEP 1-3: INGEST, CLASSIFY, TIMESTAMP
    # ─────────────────────────────────────────────────────────

    def _ingest_signals(self, raw_signals: list[SignalIngestRequest], sector: Sector, nation_id: str) -> list[Signal]:
        """Normalise raw signal requests into Signal objects with provenance."""
        signals = []
        for raw in raw_signals:
            sig = Signal(
                signal_type=raw.signal_type,
                source_id=raw.source_id,
                source_type=raw.source_type,
                sector=sector,
                nation_id=nation_id,
                payload=raw.payload,
                ttl_seconds=raw.ttl_seconds,
                tags=raw.tags,
                timestamp_utc=datetime.now(timezone.utc),
            )
            signals.append(sig)
        return signals

    # ─────────────────────────────────────────────────────────
    # STEP 4: FRESHNESS DECAY
    # ─────────────────────────────────────────────────────────

    def _compute_freshness(self, signals: list[Signal]) -> list[Signal]:
        """Apply exponential freshness decay to each signal."""
        now = datetime.now(timezone.utc)
        for sig in signals:
            age_hours = (now - sig.timestamp_utc).total_seconds() / 3600
            sig.age_hours = round(age_hours, 4)
            freshness, _ = ConfidenceEngine.compute_freshness(age_hours, sig.sector, sig.signal_type)
            sig.freshness = freshness
        return signals

    # ─────────────────────────────────────────────────────────
    # STEP 5: SOURCE RELIABILITY
    # ─────────────────────────────────────────────────────────

    def _assess_source_reliability(self, signals: list[Signal]) -> float:
        """
        Compute average source reliability.
        In production this queries the audit store's source track record.
        In this reference implementation we use source_type as a proxy.
        """
        reliability_map = {
            "formal_institution": 0.80,
            "api_feed":           0.75,
            "satellite":          0.85,
            "informal_operator":  0.60,
            "community_source":   0.55,
            "manual_entry":       0.50,
        }
        scores = [reliability_map.get(s.source_type.value, 0.50) for s in signals]
        return round(sum(scores) / len(scores), 4) if scores else 0.50

    # ─────────────────────────────────────────────────────────
    # STEP 6: TRAIL
    # ─────────────────────────────────────────────────────────

    def _create_trail(self, objective: str, signals: list[Signal], sector: Sector, nation_id: str) -> Trail:
        return Trail(
            objective=objective,
            sector=sector,
            nation_id=nation_id,
            signals=signals,
            created_at=datetime.now(timezone.utc),
        )

    # ─────────────────────────────────────────────────────────
    # STEP 8-9: CONFIDENCE + VALIDATION STATE
    # ─────────────────────────────────────────────────────────

    def _compute_confidence(
        self,
        signals: list[Signal],
        sector: Sector,
        nation_id: str,
        source_reliability: float,
        contradiction_penalty: float,
    ):
        avg_freshness   = sum(s.freshness or 0.0 for s in signals) / max(len(signals), 1)
        evidence_scores = [self._score_evidence(s) for s in signals]
        avg_evidence    = sum(evidence_scores) / max(len(evidence_scores), 1)
        consistency     = self._score_consistency(signals)

        conf_input = ConfidenceInput(
            sector=sector,
            nation_id=nation_id,
            evidence_strength=avg_evidence,
            signal_freshness=avg_freshness,
            source_reliability=source_reliability,
            cross_signal_consistency=consistency,
            domain_stability_modifier=0.65,  # default; overridden by sector pack in production
            contradiction_penalty=contradiction_penalty,
        )
        return ConfidenceEngine.score(conf_input)

    def _score_evidence(self, signal: Signal) -> float:
        """Heuristic evidence strength from payload richness."""
        payload = signal.payload
        if not payload:
            return 0.20
        numeric_count  = sum(1 for v in payload.values() if isinstance(v, (int, float)))
        has_source_ref = "source_ref" in payload or "reference" in payload
        has_timestamp  = "reported_at" in payload or "collected_at" in payload
        score = 0.40 + (numeric_count * 0.10) + (0.15 if has_source_ref else 0) + (0.10 if has_timestamp else 0)
        return round(min(1.0, score), 4)

    def _score_consistency(self, signals: list[Signal]) -> float:
        """Score cross-signal consistency by signal_type grouping."""
        if len(signals) < 2:
            return 0.50
        type_groups: dict[str, list] = {}
        for s in signals:
            type_groups.setdefault(s.signal_type, []).append(s)
        # Groups with multiple signals that agree increase consistency
        consistent_groups = sum(1 for grp in type_groups.values() if len(grp) >= 2)
        return round(min(1.0, 0.50 + (consistent_groups * 0.15)), 4)

    # ─────────────────────────────────────────────────────────
    # STEP 14: LLM REASONING WITH UBUNTU LENS
    # ─────────────────────────────────────────────────────────

    async def _reason_with_llm(
        self,
        objective: str,
        sector: Sector,
        nation_id: str,
        validation_state: ValidationState,
        confidence: float,
        contradiction_count: int,
        signals: list[Signal],
        hae_flags: list[str],
        ecology_state: str,
        inclusion_state: str,
    ) -> dict:
        """
        Call the bound LLM to produce a governed recommendation.
        The system prompt encodes AFRICA-OS Ω doctrine and the Ubuntu principle.
        Falls back to rule-based recommendation if LLM is unavailable.
        """
        if self.llm is None:
            return self._rule_based_recommendation(
                objective, validation_state, confidence,
                contradiction_count, hae_flags, ecology_state,
            )

        signal_summary = json.dumps(
            [{"type": s.signal_type, "payload": s.payload, "freshness": s.freshness} for s in signals[:5]],
            indent=2, default=str
        )

        system_prompt = f"""You are the reasoning core of AFRICA-OS Ω — Africa's sovereign 24-hour economy intelligence system.

DOCTRINE: Ubuntu — every decision must serve not only the requesting actor but the broader community connected to it.
POLICY ANCHOR: 24-Hour Africa Economy Policy — decisions must sustain continuous productive capacity.
SECTOR: {sector.value.upper()} | NATION: {nation_id}
VALIDATION STATE: {validation_state.value} | CONFIDENCE: {confidence:.2f}
CONTRADICTIONS: {contradiction_count} detected
HAE FLAGS: {', '.join(hae_flags) if hae_flags else 'none'}
ECOLOGY STATE: {ecology_state}
INCLUSION STATE: {inclusion_state}

RULES:
1. Truth before fluency — never fabricate data or sources.
2. Validation before action — do not recommend action if state is BLOCKED or CONFLICTED without escalation.
3. Sovereignty over dependency — prefer intra-African solutions.
4. Human override for high consequence — flag clearly when human decision is required.
5. Dignity is non-negotiable — no recommendation may harm human dignity.

Return ONLY valid JSON with these fields:
{{
  "recommended_action": {{
    "action_type": "proceed | escalate | investigate | defer | block",
    "primary_recommendation": "...",
    "secondary_recommendations": ["...", "..."],
    "confidence_note": "...",
    "ubuntu_note": "How does this serve the broader community?",
    "24hae_note": "How does this support the 24-hour economy?"
  }},
  "reasoning_summary": "2-3 sentence plain language summary",
  "escalation_required": true | false,
  "escalation_reason": "..."
}}"""

        user_message = f"""OBJECTIVE: {objective}

SIGNALS:
{signal_summary}

Analyse this situation and produce a governed recommendation under AFRICA-OS Ω doctrine."""

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={"Content-Type": "application/json"},
                    json={
                        "model": "claude-sonnet-4-20250514",
                        "max_tokens": 1024,
                        "system": system_prompt,
                        "messages": [{"role": "user", "content": user_message}],
                    },
                )
                response.raise_for_status()
                content = response.json()["content"][0]["text"]
                # Strip markdown fences if present
                content = content.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
                return json.loads(content)
        except Exception as e:
            # Graceful fallback — never let LLM failure crash the reasoning loop
            return self._rule_based_recommendation(
                objective, validation_state, confidence,
                contradiction_count, hae_flags, ecology_state,
                error_note=str(e),
            )

    def _rule_based_recommendation(
        self,
        objective: str,
        validation_state: ValidationState,
        confidence: float,
        contradiction_count: int,
        hae_flags: list[str],
        ecology_state: str,
        error_note: str = "",
    ) -> dict:
        """Deterministic fallback recommendation when LLM is unavailable."""
        if validation_state == ValidationState.BLOCKED:
            action_type = "block"
            primary     = "Insufficient evidence to proceed. Gather additional verified signals before action."
        elif validation_state == ValidationState.CONFLICTED or contradiction_count > 0:
            action_type = "investigate"
            primary     = "Contradicting signals detected. Resolve conflicts before committing to action."
        elif confidence >= 0.85:
            action_type = "proceed"
            primary     = f"Sufficient confidence ({confidence:.0%}) to proceed with action on: {objective}"
        else:
            action_type = "defer"
            primary     = f"Provisional confidence ({confidence:.0%}). Seek additional signal verification before action."

        ubuntu_note = "Ensure all affected community actors are consulted before implementation."
        hae_note    = "Verify this action sustains 24-hour productive continuity before proceeding."

        if "WORKER_DIGNITY_AT_RISK" in hae_flags:
            action_type = "escalate"
            primary     = "CRITICAL: Worker dignity risk detected. Escalate to sector lead before any action."

        return {
            "recommended_action": {
                "action_type": action_type,
                "primary_recommendation": primary,
                "secondary_recommendations": [
                    "Document all signal sources for audit trail.",
                    "Notify relevant sector lead of decision outcome.",
                ],
                "confidence_note": f"Confidence: {confidence:.0%} | State: {validation_state.value}",
                "ubuntu_note": ubuntu_note,
                "24hae_note": hae_note,
            },
            "reasoning_summary": primary,
            "escalation_required": action_type in ("block", "escalate"),
            "escalation_reason": f"Validation state: {validation_state.value}. {error_note}".strip(),
        }

    # ─────────────────────────────────────────────────────────
    # ESCALATION CHECK
    # ─────────────────────────────────────────────────────────

    def _requires_escalation(
        self,
        validation_state: ValidationState,
        contradiction_count: int,
        ecology_state: str,
        hae_flags: list[str],
        local_fit: LocalFitResult,
        high_consequence: bool,
        llm_says_escalate: bool,
    ) -> tuple[bool, EscalationPriority, str]:
        reasons = []

        if validation_state == ValidationState.BLOCKED:
            reasons.append("Validation state BLOCKED")
        if contradiction_count > 0 and validation_state == ValidationState.CONFLICTED:
            reasons.append(f"{contradiction_count} unresolved contradictions")
        if ecology_state == "critical":
            reasons.append("EIS critical threshold exceeded")
        if "WORKER_DIGNITY_AT_RISK" in hae_flags:
            reasons.append("Worker dignity guardrail triggered")
        if local_fit.hard_fail_triggered:
            reasons.append(f"Local fit hard-fail: {', '.join(local_fit.dimensions_failed)}")
        if high_consequence:
            reasons.append("High-consequence flag set by requestor")
        if llm_says_escalate:
            reasons.append("Reasoning engine flagged for human review")

        if not reasons:
            return False, EscalationPriority.LOW, ""

        if any(r in reasons for r in ["Worker dignity guardrail triggered", "EIS critical threshold exceeded", "Validation state BLOCKED"]):
            priority = EscalationPriority.CRITICAL
        elif high_consequence or local_fit.hard_fail_triggered:
            priority = EscalationPriority.HIGH
        else:
            priority = EscalationPriority.MEDIUM

        return True, priority, " | ".join(reasons)

    # ─────────────────────────────────────────────────────────
    # MAIN ENTRY POINT — 19-STEP REASONING CONTRACT
    # ─────────────────────────────────────────────────────────

    async def run(self, request: DecisionRequest) -> tuple[DecisionObject, Optional[EscalationItem]]:
        """
        Execute the full AFRICA-OS Ω reasoning contract.
        Returns (DecisionObject, Optional[EscalationItem])
        """
        guardrail_events = []

        # ── STEPS 1-3: Ingest, classify, timestamp ──────────
        signals = self._ingest_signals(request.signals, request.sector, request.nation_id)

        # ── STEP 4: Freshness decay ──────────────────────────
        signals = self._compute_freshness(signals)

        # ── STEP 5: Source reliability ───────────────────────
        source_reliability = self._assess_source_reliability(signals)

        # ── STEP 6: Trail ────────────────────────────────────
        trail = self._create_trail(request.objective, signals, request.sector, request.nation_id)

        # ── STEP 7: Contradiction detection ──────────────────
        contradiction = ContradictionEngine.evaluate(signals)
        if contradiction.severity_label.value in ("moderate", "severe"):
            guardrail_events.append(f"contradiction_guardrail: {contradiction.severity_label.value} ({contradiction.contradiction_count} conflicts)")

        # ── STEPS 8-9: Confidence + validation state ─────────
        conf_result = self._compute_confidence(
            signals, request.sector, request.nation_id,
            source_reliability, contradiction.contradiction_penalty,
        )
        guardrail_events.append(f"confidence: {conf_result.confidence:.3f} → {conf_result.validation_state.value}")

        # ── STEP 10: Inclusion check ──────────────────────────
        incl_input = request.inclusion_context or InclusionInput(
            sector=request.sector, nation_id=request.nation_id
        )
        inclusion = InclusionEngine.score(incl_input)
        if inclusion.inclusion_state == "exclusionary":
            guardrail_events.append(f"inclusion_guardrail: flagged dims — {inclusion.flagged_dimensions}")

        # ── STEP 11: 24HAE policy precheck ───────────────────
        hae_input = request.hae_context or HaeInput(
            sector=request.sector, nation_id=request.nation_id
        )
        hae = HaeEngine.evaluate(hae_input)
        if hae.policy_flags:
            guardrail_events.append(f"24hae_policy: flags — {hae.policy_flags}")

        # ── STEP 12: Ecology check ────────────────────────────
        eco_input = request.ecology_context or EcologyInput(
            sector=request.sector, nation_id=request.nation_id
        )
        ecology = EcologyEngine.score(eco_input)
        if ecology.eis_state.value in ("warning", "critical"):
            guardrail_events.append(f"ecology_guardrail: EIS {ecology.eis_score:.3f} → {ecology.eis_state.value}")

        # ── STEP 13: IntraAfrican trade alignment (heuristic) ─
        # In production: queries /v1/afcfta/corridor-status
        intra_african_aligned = hae_input.intra_african_value_creation

        # ── STEPS 14-15: LLM reasoning with Ubuntu lens ──────
        llm_result = await self._reason_with_llm(
            objective=request.objective,
            sector=request.sector,
            nation_id=request.nation_id,
            validation_state=conf_result.validation_state,
            confidence=conf_result.confidence,
            contradiction_count=contradiction.contradiction_count,
            signals=signals,
            hae_flags=hae.policy_flags,
            ecology_state=ecology.eis_state.value,
            inclusion_state=inclusion.inclusion_state,
        )

        # ── STEP 16: Policy postcheck ─────────────────────────
        # Truth guardrail — flag if LLM output is suspiciously confident without evidence
        if conf_result.validation_state == ValidationState.BLOCKED:
            if llm_result.get("recommended_action", {}).get("action_type") == "proceed":
                llm_result["recommended_action"]["action_type"] = "block"
                guardrail_events.append("truth_guardrail: overrode LLM proceed to block (BLOCKED validation state)")

        # ── STEP 17: Local fit test ───────────────────────────
        local_fit = LocalFitEngine.evaluate(
            sector=request.sector,
            nation_id=request.nation_id,
        )
        if not local_fit.local_fit_passed:
            guardrail_events.append(f"local_fit_guardrail: failed dims — {local_fit.dimensions_failed}")

        # ── STEP 18: Escalation determination ────────────────
        needs_escalation, esc_priority, esc_reason = self._requires_escalation(
            validation_state=conf_result.validation_state,
            contradiction_count=contradiction.contradiction_count,
            ecology_state=ecology.eis_state.value,
            hae_flags=hae.policy_flags,
            local_fit=local_fit,
            high_consequence=request.high_consequence,
            llm_says_escalate=llm_result.get("escalation_required", False),
        )

        allowed_for_action = (
            conf_result.validation_state in (ValidationState.TRUSTED, ValidationState.PROVISIONAL)
            and contradiction.severity_label.value != "severe"
            and ecology.eis_state != "critical"
            and "WORKER_DIGNITY_AT_RISK" not in hae.policy_flags
            and not local_fit.hard_fail_triggered
        )

        # ── STEP 18: Audit ref ────────────────────────────────
        audit_ref = f"AUD-{uuid.uuid4().hex[:12].upper()}"

        # ── STEP 19: Build decision object ───────────────────
        decision = DecisionObject(
            objective=request.objective,
            sector=request.sector,
            nation_id=request.nation_id,
            validation_state=conf_result.validation_state,
            confidence=conf_result.confidence,
            contradiction_count=contradiction.contradiction_count,
            ecology_score=ecology.eis_score,
            inclusion_score=inclusion.inclusion_score,
            hae_alignment_score=hae.hae_alignment_score,
            recommended_action=llm_result.get("recommended_action", {}),
            human_escalation_required=needs_escalation,
            allowed_for_action=allowed_for_action,
            local_fit_passed=local_fit.local_fit_passed,
            local_fit_report=local_fit,
            reasoning_summary=llm_result.get("reasoning_summary", ""),
            audit_ref=audit_ref,
        )

        # Write audit entry
        audit_entry = AuditEntry(
            audit_ref=audit_ref,
            decision_id=decision.decision_id,
            sector=request.sector,
            nation_id=request.nation_id,
            objective=request.objective,
            signal_count=len(signals),
            validation_state=conf_result.validation_state,
            confidence=conf_result.confidence,
            contradiction_count=contradiction.contradiction_count,
            ecology_score=ecology.eis_score,
            inclusion_score=inclusion.inclusion_score,
            hae_alignment_score=hae.hae_alignment_score,
            guardrail_events=guardrail_events,
            escalation_triggered=needs_escalation,
            reasoning_summary=decision.reasoning_summary,
        )
        await self.audit.write(audit_entry)

        # Build escalation if required
        escalation = None
        if needs_escalation:
            from core.sector_packs import get_sector_pack
            pack = get_sector_pack(request.sector)
            escalation = EscalationItem(
                objective=request.objective,
                sector=request.sector,
                nation_id=request.nation_id,
                priority=esc_priority,
                reason=esc_reason,
                decision_ref=decision.decision_id,
                assigned_role=Role.SECTOR_LEAD,
                sla_minutes=30 if esc_priority == EscalationPriority.CRITICAL else 60,
            )

        return decision, escalation
