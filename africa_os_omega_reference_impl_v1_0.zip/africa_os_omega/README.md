# AFRICA-OS Ω — Reference Implementation

**Africa's sovereign 24-hour economy reasoning operating system.**

> *Africa reasoning in real time — always on, always governed, always African.*

**Creator:** Dr. David King Boison  
**Version:** 1.0.0  
**Base Nation:** Ghana  
**Continental Scope:** African Union — 55 member states  
**Anchor Policy:** 24-Hour Africa Economy Policy  
**Epistemic Root:** Ubuntu — I am because we are

---

## What This Is

AFRICA-OS Ω is a sovereign, validation-first reasoning layer that sits above any LLM
and any legacy system to transform fragmented signals into governed, auditable decisions
across every sector of Africa's economy.

This repository is the **reference FastAPI implementation** of the AFRICA-OS Ω reasoning
loop, covering all 8 core sectors:

| Sector | 24HAE Priority | Lambda (λ) | Half-life |
|--------|---------------|-----------|-----------|
| Health | CRITICAL | 0.693 | 1 hour |
| Agriculture | CRITICAL | 0.035 | 20 hours |
| Finance | CRITICAL | 0.347 | 2 hours |
| Energy | CRITICAL | 0.231 | 3 hours |
| Transport | HIGH | 0.139 | 5 hours |
| Education | HIGH | 0.020 | 35 hours |
| Governance | HIGH | 0.020 | 35 hours |
| Ports | HIGH | 0.099 | 7 hours |

---

## Quick Start

```bash
# 1. Clone and enter
cd africa_os_omega

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY (optional — falls back to rule-based)

# 4. Run the server
uvicorn api.main:app --reload --port 8000

# 5. Open the API docs
# http://localhost:8000/docs
```

---

## Running the Tests

```bash
pytest tests/ -v
# Expected: 23 passed
```

---

## Architecture

```
africa_os_omega/
├── api/
│   └── main.py              # FastAPI app — all endpoints
├── core/
│   ├── reasoning_loop.py    # 19-step reasoning contract
│   ├── sector_packs.py      # All 8 sector configurations
│   └── audit.py             # Append-only audit store
├── engines/
│   └── reasoning_engines.py # 6 reasoning engines
├── models/
│   └── schemas.py           # All Pydantic data models
└── tests/
    └── test_reasoning.py    # 23 tests across all engines + loop
```

---

## The 19-Step Reasoning Contract

Every call to `POST /v1/decisions/resolve` executes:

```
1.  ingest_signal
2.  classify_signal_and_sector
3.  attach_provenance_and_timestamp
4.  evaluate_freshness_with_domain_lambda
5.  evaluate_source_reliability
6.  attach_or_create_trail
7.  detect_contradictions_and_assign_severity
8.  compute_confidence_score
9.  assign_validation_state
10. run_inclusion_check
11. run_policy_precheck_24hae
12. run_ecology_check_EIS
13. evaluate_intra_african_trade_alignment
14. reason_over_options_with_ubuntu_lens  ← LLM or rule-based fallback
15. generate_decision_object
16. run_policy_postcheck
17. run_local_fit_test
18. create_audit_ref
19. return_or_escalate
```

---

## Key Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/v1/decisions/resolve` | Full 19-step reasoning loop |
| POST | `/v1/signals/ingest` | Ingest a signal from any source |
| POST | `/v1/confidence/score` | Score confidence for a signal set |
| POST | `/v1/confidence/freshness` | Compute lambda decay freshness |
| POST | `/v1/contradictions/evaluate` | Detect signal contradictions |
| POST | `/v1/ecology/score` | Compute Ecology Impact Score |
| POST | `/v1/inclusion/score` | Score decision inclusion |
| POST | `/v1/24hae/evaluate` | 24-Hour Economy policy alignment |
| POST | `/v1/audit/replay` | Replay a decision by audit ref |
| GET | `/v1/sector-packs/{sector}` | View sector pack config |

---

## Example: Health Sector Decision

```bash
curl -X POST http://localhost:8000/v1/decisions/resolve \
  -H "Content-Type: application/json" \
  -H "x-api-key: africa-os-dev-key" \
  -d '{
    "objective": "Assess ICU capacity at Korle Bu Teaching Hospital",
    "sector": "health",
    "nation_id": "GH",
    "signals": [
      {
        "signal_type": "bed_capacity_signal",
        "source_id": "korle_bu_emr",
        "source_type": "formal_institution",
        "sector": "health",
        "payload": {
          "available_icu_beds": 3,
          "total_icu_beds": 20,
          "occupancy_rate": 0.85,
          "source_ref": "KBH-ICU-2026-04"
        }
      }
    ],
    "high_consequence": true
  }'
```

---

## LLM Integration

AFRICA-OS Ω calls the configured LLM (default: Anthropic Claude) at Step 14
with the full AFRICA-OS Ω doctrine encoded in the system prompt, including:
- Ubuntu principle
- 24-Hour Africa Economy Policy
- All active guardrails
- Sector and confidence context

If no API key is set or the LLM is unavailable, the system falls back to a
deterministic rule-based recommendation. **The reasoning loop never fails due
to LLM unavailability** — this is by design for African deployment contexts
where connectivity cannot be assumed.

---

## Next Steps (Roadmap)

- [ ] Supabase integration for persistent trail and audit storage
- [ ] Entrepreneur Intelligence Interface (mobile-first)
- [ ] Continental Federation Schema (AfCFTA multi-nation signal sharing)
- [ ] Remaining sector packs: Manufacturing, Mining, ICT, Water, Tourism
- [ ] 24HAE Situation Room Dashboard
- [ ] SMS/USSD adapter for low-connectivity field operators

---

## Attribution

All deployments and derivatives must maintain attribution to **Dr. David King Boison**
as the creator of AFRICA-OS Ω, the Visionary Prompt Framework (VPF), and the
24-Hour Africa Economy Policy as implemented herein.
