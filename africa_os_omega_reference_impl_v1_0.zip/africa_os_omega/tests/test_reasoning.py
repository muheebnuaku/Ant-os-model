"""
AFRICA-OS Ω — Test Suite
===========================
Tests for all six reasoning engines and the full decision loop.
Run with: pytest tests/ -v

Creator: Dr. David King Boison
"""

import pytest
import asyncio
import math

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from models.schemas import (
    Sector, ValidationState, SourceType,
    ConfidenceInput, EcologyInput, InclusionInput, HaeInput,
    SignalIngestRequest, DecisionRequest,
    EnvironmentalImpact, SocialImpact, ResourceStress,
)
from engines.reasoning_engines import (
    ConfidenceEngine, ContradictionEngine, EcologyEngine,
    InclusionEngine, HaeEngine, LocalFitEngine,
)
from core.sector_packs import get_sector_pack
from core.audit import AuditStore
from core.reasoning_loop import ReasoningLoop


# ─────────────────────────────────────────────────────────────
# ENGINE 1: CONFIDENCE
# ─────────────────────────────────────────────────────────────

class TestConfidenceEngine:

    def test_high_confidence_returns_trusted(self):
        inp = ConfidenceInput(
            sector=Sector.HEALTH,
            evidence_strength=0.95,
            signal_freshness=0.90,
            source_reliability=0.85,
            cross_signal_consistency=0.90,
            domain_stability_modifier=0.80,
            contradiction_penalty=0.00,
        )
        result = ConfidenceEngine.score(inp)
        assert result.validation_state == ValidationState.TRUSTED
        assert result.confidence >= 0.85

    def test_low_confidence_returns_blocked(self):
        inp = ConfidenceInput(
            sector=Sector.FINANCE,
            evidence_strength=0.10,
            signal_freshness=0.10,
            source_reliability=0.10,
            cross_signal_consistency=0.10,
            domain_stability_modifier=0.10,
            contradiction_penalty=0.50,
        )
        result = ConfidenceEngine.score(inp)
        assert result.validation_state in (ValidationState.BLOCKED, ValidationState.CONFLICTED)

    def test_freshness_decay_health_fast(self):
        """Health signals decay fast — half-life 1 hour."""
        freshness_0h, lam = ConfidenceEngine.compute_freshness(0, Sector.HEALTH)
        freshness_1h, _   = ConfidenceEngine.compute_freshness(1, Sector.HEALTH)
        freshness_3h, _   = ConfidenceEngine.compute_freshness(3, Sector.HEALTH)
        assert freshness_0h == 1.0
        assert abs(freshness_1h - 0.5) < 0.01  # half-life = 1h → ~0.5
        assert freshness_3h < 0.15

    def test_freshness_decay_governance_slow(self):
        """Governance signals decay slowly — half-life 35 hours."""
        freshness_0h, _  = ConfidenceEngine.compute_freshness(0, Sector.GOVERNANCE)
        freshness_35h, _ = ConfidenceEngine.compute_freshness(35, Sector.GOVERNANCE)
        assert freshness_0h == 1.0
        assert abs(freshness_35h - 0.5) < 0.05  # half-life = 35h → ~0.5

    def test_finance_domain_modifier_boosts_score(self):
        """Finance modifier 1.20 should produce higher confidence than transport (1.00)."""
        base = ConfidenceInput(
            sector=Sector.FINANCE,
            evidence_strength=0.70,
            signal_freshness=0.70,
            source_reliability=0.70,
            cross_signal_consistency=0.70,
            domain_stability_modifier=0.70,
            contradiction_penalty=0.0,
        )
        finance_result = ConfidenceEngine.score(base)
        transport_result = ConfidenceEngine.score(base.model_copy(update={"sector": Sector.TRANSPORT}))
        assert finance_result.confidence > transport_result.confidence


# ─────────────────────────────────────────────────────────────
# ENGINE 2: CONTRADICTION
# ─────────────────────────────────────────────────────────────

class TestContradictionEngine:

    def _make_signal(self, signal_type, value, sector=Sector.HEALTH):
        from models.schemas import Signal
        return Signal(
            signal_type=signal_type,
            source_id="test-source",
            sector=sector,
            nation_id="GH",
            payload={"value": value},
        )

    def test_no_contradiction_on_single_signal(self):
        sig = self._make_signal("bed_capacity_signal", 0.80)
        result = ContradictionEngine.evaluate([sig])
        assert result.contradiction_count == 0
        assert result.contradiction_penalty == 0.0

    def test_minor_contradiction_detected(self):
        sig_a = self._make_signal("bed_capacity_signal", 0.80)
        sig_b = self._make_signal("bed_capacity_signal", 0.65)  # diff=0.15 > tolerance 0.08
        result = ContradictionEngine.evaluate([sig_a, sig_b])
        assert result.contradiction_count > 0

    def test_severe_contradiction_triggers_block(self):
        sig_a = self._make_signal("bed_capacity_signal", 0.95)
        sig_b = self._make_signal("bed_capacity_signal", 0.10)  # extreme diff
        result = ContradictionEngine.evaluate([sig_a, sig_b])
        assert result.recommended_action == "block_and_escalate"
        assert result.contradiction_penalty >= 0.40

    def test_different_signal_types_no_contradiction(self):
        from models.schemas import Signal
        sig_a = Signal(signal_type="bed_capacity_signal",  source_id="a", sector=Sector.HEALTH, nation_id="GH", payload={"value": 0.9})
        sig_b = Signal(signal_type="drug_stock_level",     source_id="b", sector=Sector.HEALTH, nation_id="GH", payload={"value": 0.1})
        result = ContradictionEngine.evaluate([sig_a, sig_b])
        assert result.contradiction_count == 0  # different types = no comparison


# ─────────────────────────────────────────────────────────────
# ENGINE 3: ECOLOGY
# ─────────────────────────────────────────────────────────────

class TestEcologyEngine:

    def test_zero_impact_returns_acceptable(self):
        inp = EcologyInput(sector=Sector.AGRICULTURE, nation_id="GH")
        result = EcologyEngine.score(inp)
        assert result.eis_state.value == "acceptable"
        assert result.eis_score == 0.0

    def test_high_impact_returns_critical(self):
        inp = EcologyInput(
            sector=Sector.ENERGY,
            nation_id="GH",
            environmental_impact=EnvironmentalImpact(
                carbon_emission_delta=1.0,
                land_use_change_risk=1.0,
                water_contamination_risk=1.0,
                biodiversity_disruption_index=1.0,
                waste_generation_level=1.0,
            ),
            social_impact=SocialImpact(
                community_displacement_risk=1.0,
                health_risk_to_population=1.0,
                equity_impact_score=1.0,
                cultural_heritage_risk=1.0,
                livelihood_disruption_index=1.0,
            ),
            resource_stress=ResourceStress(
                water_extraction_rate=1.0,
                energy_demand_stress=1.0,
                soil_degradation_index=1.0,
                infrastructure_load_factor=1.0,
                raw_material_depletion_risk=1.0,
            ),
        )
        result = EcologyEngine.score(inp)
        assert result.eis_state.value == "critical"
        assert result.eis_score >= 0.75

    def test_health_lower_critical_threshold(self):
        """Health sector has critical threshold at 0.70 (lower than default 0.75)."""
        pack = get_sector_pack(Sector.HEALTH)
        assert pack.eis_critical_threshold == 0.70


# ─────────────────────────────────────────────────────────────
# ENGINE 4: INCLUSION
# ─────────────────────────────────────────────────────────────

class TestInclusionEngine:

    def test_fully_inclusive_passes(self):
        inp = InclusionInput(
            sector=Sector.AGRICULTURE,
            informal_economy_reach=0.90,
            rural_reach=0.85,
            gender_equity_score=0.80,
            youth_inclusion_score=0.75,
            disability_inclusion_score=0.70,
        )
        result = InclusionEngine.score(inp)
        assert result.inclusion_state == "inclusive"
        assert result.inclusion_score >= 0.60

    def test_exclusionary_flags_dimensions(self):
        inp = InclusionInput(
            sector=Sector.FINANCE,
            informal_economy_reach=0.10,
            rural_reach=0.10,
            gender_equity_score=0.10,
            youth_inclusion_score=0.10,
            disability_inclusion_score=0.10,
        )
        result = InclusionEngine.score(inp)
        assert result.inclusion_state == "exclusionary"
        assert len(result.flagged_dimensions) > 0


# ─────────────────────────────────────────────────────────────
# ENGINE 5: 24HAE
# ─────────────────────────────────────────────────────────────

class TestHaeEngine:

    def test_fully_aligned_decision(self):
        inp = HaeInput(
            sector=Sector.AGRICULTURE,
            productive_capacity_impact=0.80,
            intra_african_value_creation=True,
            informal_actor_inclusion=True,
            worker_dignity_preserved=True,
            dependency_reduction=True,
        )
        result = HaeEngine.evaluate(inp)
        assert result.hae_state.value == "aligned"
        assert result.hae_alignment_score >= 0.75

    def test_worker_dignity_flag_triggers(self):
        inp = HaeInput(
            sector=Sector.TRANSPORT,
            productive_capacity_impact=0.50,
            worker_dignity_preserved=False,
        )
        result = HaeEngine.evaluate(inp)
        assert "WORKER_DIGNITY_AT_RISK" in result.policy_flags

    def test_negative_capacity_flags_correctly(self):
        inp = HaeInput(
            sector=Sector.ENERGY,
            productive_capacity_impact=-0.50,
        )
        result = HaeEngine.evaluate(inp)
        assert "REDUCES_PRODUCTIVE_CAPACITY" in result.policy_flags


# ─────────────────────────────────────────────────────────────
# ENGINE 6: LOCAL FIT
# ─────────────────────────────────────────────────────────────

class TestLocalFitEngine:

    def test_all_pass_returns_local_fit_passed(self):
        result = LocalFitEngine.evaluate(sector=Sector.HEALTH, nation_id="GH")
        assert result.local_fit_passed is True
        assert result.dimensions_passed == 6

    def test_hard_fail_on_regulatory_grounding(self):
        result = LocalFitEngine.evaluate(
            sector=Sector.GOVERNANCE,
            nation_id="GH",
            regulatory_grounded=False,
        )
        assert result.hard_fail_triggered is True
        assert result.local_fit_passed is False
        assert result.escalation_triggered is True

    def test_hard_fail_on_institutional_alignment(self):
        result = LocalFitEngine.evaluate(
            sector=Sector.HEALTH,
            nation_id="GH",
            has_valid_institution=False,
        )
        assert result.hard_fail_triggered is True
        assert result.local_fit_passed is False


# ─────────────────────────────────────────────────────────────
# FULL REASONING LOOP
# ─────────────────────────────────────────────────────────────

class TestReasoningLoop:

    @pytest.fixture
    def loop(self, tmp_path):
        audit = AuditStore(log_path=str(tmp_path))
        return ReasoningLoop(audit_store=audit, llm_client=None)

    @pytest.mark.asyncio
    async def test_health_decision_completes(self, loop):
        """A well-evidenced health signal set should produce a trusted decision."""
        request = DecisionRequest(
            objective="Assess bed capacity at Korle Bu Teaching Hospital",
            sector=Sector.HEALTH,
            nation_id="GH",
            signals=[
                SignalIngestRequest(
                    signal_type="bed_capacity_signal",
                    source_id="korle_bu_emr",
                    source_type=SourceType.FORMAL_INSTITUTION,
                    sector=Sector.HEALTH,
                    payload={"available_beds": 47, "total_beds": 120, "occupancy_rate": 0.61, "source_ref": "KBH-EMR-2026"},
                ),
                SignalIngestRequest(
                    signal_type="bed_capacity_signal",
                    source_id="ghs_dashboard",
                    source_type=SourceType.API_FEED,
                    sector=Sector.HEALTH,
                    payload={"available_beds": 45, "total_beds": 120, "occupancy_rate": 0.625},
                ),
            ],
            high_consequence=False,
        )
        decision, escalation = await loop.run(request)
        assert decision.decision_id.startswith("DEC-")
        assert decision.audit_ref.startswith("AUD-")
        assert decision.confidence >= 0.0
        assert decision.sector == Sector.HEALTH

    @pytest.mark.asyncio
    async def test_worker_dignity_forces_escalation(self, loop):
        """Worker dignity risk must always trigger escalation."""
        request = DecisionRequest(
            objective="Extend port shift hours to 20 hours per day",
            sector=Sector.PORTS,
            nation_id="GH",
            signals=[
                SignalIngestRequest(
                    signal_type="berth_occupancy",
                    source_id="gpha_pms",
                    source_type=SourceType.API_FEED,
                    sector=Sector.PORTS,
                    payload={"occupancy_rate": 0.95},
                ),
            ],
            hae_context=HaeInput(
                sector=Sector.PORTS,
                nation_id="GH",
                worker_dignity_preserved=False,
                productive_capacity_impact=0.30,
            ),
        )
        decision, escalation = await loop.run(request)
        assert decision.human_escalation_required is True
        assert escalation is not None

    @pytest.mark.asyncio
    async def test_audit_entry_written(self, loop, tmp_path):
        """Every decision must produce an audit entry."""
        request = DecisionRequest(
            objective="Test audit write",
            sector=Sector.FINANCE,
            nation_id="GH",
            signals=[
                SignalIngestRequest(
                    signal_type="liquidity_signal",
                    source_id="bog_rtgs",
                    source_type=SourceType.API_FEED,
                    sector=Sector.FINANCE,
                    payload={"liquidity_ratio": 0.75},
                ),
            ],
        )
        decision, _ = await loop.run(request)
        # Replay from audit store
        record = await loop.audit.replay(decision.audit_ref)
        assert record is not None
        assert record["audit_ref"] == decision.audit_ref
        assert record["sector"] == "finance"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
