"""
AFRICA-OS Ω — FastAPI Application
=====================================
The main API server. Wires all engines, the reasoning loop,
and all endpoints into a single deployable service.

Run with:
  uvicorn api.main:app --reload --port 8000

Creator: Dr. David King Boison
"""

import os
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Depends, Header, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from models.schemas import (
    SignalIngestRequest, SignalIngestResponse,
    TrailRequest, TrailResponse,
    ConfidenceInput, ConfidenceResult,
    EcologyInput, EcologyResult,
    InclusionInput, InclusionResult,
    HaeInput, HaeResult,
    DecisionRequest, DecisionObject,
    EscalationItem, AuditEntry,
    Sector, Role,
)
from engines.reasoning_engines import (
    ConfidenceEngine, ContradictionEngine,
    EcologyEngine, InclusionEngine, HaeEngine, LocalFitEngine,
)
from core.reasoning_loop import ReasoningLoop
from core.audit import AuditStore
from core.sector_packs import get_sector_pack


# ─────────────────────────────────────────────────────────────
# APP LIFESPAN — startup / shutdown
# ─────────────────────────────────────────────────────────────

audit_store: AuditStore = None
reasoning_loop: ReasoningLoop = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global audit_store, reasoning_loop
    log_path = os.getenv("AUDIT_LOG_PATH", "./audit_logs")
    audit_store   = AuditStore(log_path=log_path)
    reasoning_loop = ReasoningLoop(audit_store=audit_store)
    print("✅  AFRICA-OS Ω reasoning loop initialised")
    print(f"✅  Audit store at: {log_path}")
    print("🌍  Africa reasoning in real time — always on, always governed, always African.\n")
    yield
    print("AFRICA-OS Ω shutting down gracefully.")


# ─────────────────────────────────────────────────────────────
# APP INSTANCE
# ─────────────────────────────────────────────────────────────

app = FastAPI(
    title="AFRICA-OS Ω",
    description=(
        "Africa's sovereign 24-hour economy reasoning operating system. "
        "Coordinates intelligence across Health, Agriculture, Finance, Energy, "
        "Transport, Education, Governance, and Ports. "
        "Anchored to the 24-Hour Africa Economy Policy. "
        "Built on Ubuntu — I am because we are. "
        "Creator: Dr. David King Boison."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────
# MIDDLEWARE — request timing and role logging
# ─────────────────────────────────────────────────────────────

@app.middleware("http")
async def timing_middleware(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = round((time.time() - start) * 1000, 1)
    response.headers["X-AFRICAOS-Latency-ms"] = str(duration_ms)
    response.headers["X-AFRICAOS-Version"] = "1.0.0"
    return response


# ─────────────────────────────────────────────────────────────
# AUTH DEPENDENCY (lightweight for reference implementation)
# ─────────────────────────────────────────────────────────────

API_KEY = os.getenv("API_KEY", "africa-os-dev-key")


def verify_api_key(x_api_key: str = Header(default="africa-os-dev-key")):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key.")
    return x_api_key


# ─────────────────────────────────────────────────────────────
# ROOT
# ─────────────────────────────────────────────────────────────

@app.get("/", tags=["System"])
async def root():
    return {
        "system": "AFRICA-OS Ω",
        "version": "1.0.0",
        "tagline": "Africa reasoning in real time — always on, always governed, always African.",
        "creator": "Dr. David King Boison",
        "anchor_policy": "24-Hour Africa Economy Policy",
        "active_sectors": [s.value for s in Sector],
        "status": "operational",
        "docs": "/docs",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy", "timestamp_utc": datetime.now(timezone.utc).isoformat()}


# ─────────────────────────────────────────────────────────────
# SIGNALS
# ─────────────────────────────────────────────────────────────

@app.post("/v1/signals/ingest", response_model=SignalIngestResponse, tags=["Signals"])
async def ingest_signal(
    request: SignalIngestRequest,
    _: str = Depends(verify_api_key),
):
    """
    Ingest a signal from any source into the AFRICA-OS Ω signal fabric.
    Accepts formal institution, informal operator, community, satellite, API, or manual signals.
    """
    from models.schemas import Signal
    from datetime import timezone
    import math

    sig = Signal(
        signal_type=request.signal_type,
        source_id=request.source_id,
        source_type=request.source_type,
        sector=request.sector,
        nation_id=request.nation_id,
        payload=request.payload,
        ttl_seconds=request.ttl_seconds,
        tags=request.tags,
        timestamp_utc=datetime.now(timezone.utc),
    )

    pack = get_sector_pack(request.sector)
    freshness = round(math.exp(-pack.lambda_override * 0), 4)  # age = 0 at ingest
    sig.freshness = freshness

    return SignalIngestResponse(
        accepted=True,
        signal_ref=sig.signal_id,
        freshness_at_ingest=freshness,
        validation_note=f"Signal accepted. Domain lambda={pack.lambda_override}. Half-life={pack.half_life_hours}h.",
    )


# ─────────────────────────────────────────────────────────────
# CONFIDENCE
# ─────────────────────────────────────────────────────────────

@app.post("/v1/confidence/score", response_model=ConfidenceResult, tags=["Confidence"])
async def score_confidence(
    request: ConfidenceInput,
    _: str = Depends(verify_api_key),
):
    """Compute a calibrated confidence score for a domain-specific signal set."""
    return ConfidenceEngine.score(request)


@app.post("/v1/confidence/freshness", tags=["Confidence"])
async def compute_freshness(
    sector: Sector,
    signal_type: str = "default",
    age_hours: float = 0.0,
    _: str = Depends(verify_api_key),
):
    """Compute signal freshness using domain-specific exponential decay."""
    pack = get_sector_pack(sector)
    freshness, lam = ConfidenceEngine.compute_freshness(age_hours, sector, signal_type)
    return {
        "freshness": freshness,
        "lambda_used": lam,
        "half_life_hours": pack.half_life_hours,
        "age_hours": age_hours,
        "sector": sector.value,
    }


# ─────────────────────────────────────────────────────────────
# CONTRADICTIONS
# ─────────────────────────────────────────────────────────────

@app.post("/v1/contradictions/evaluate", tags=["Contradictions"])
async def evaluate_contradictions(
    signals: list[SignalIngestRequest],
    sector: Sector,
    nation_id: str = "GH",
    _: str = Depends(verify_api_key),
):
    """Detect material contradictions across a set of signals."""
    from models.schemas import Signal
    sig_objects = [
        Signal(
            signal_type=s.signal_type,
            source_id=s.source_id,
            source_type=s.source_type,
            sector=sector,
            nation_id=nation_id,
            payload=s.payload,
            timestamp_utc=datetime.now(timezone.utc),
        )
        for s in signals
    ]
    return ContradictionEngine.evaluate(sig_objects)


# ─────────────────────────────────────────────────────────────
# ECOLOGY
# ─────────────────────────────────────────────────────────────

@app.post("/v1/ecology/score", response_model=EcologyResult, tags=["Ecology"])
async def score_ecology(
    request: EcologyInput,
    _: str = Depends(verify_api_key),
):
    """Compute the Ecology Impact Score (EIS) for a proposed action."""
    return EcologyEngine.score(request)


# ─────────────────────────────────────────────────────────────
# INCLUSION
# ─────────────────────────────────────────────────────────────

@app.post("/v1/inclusion/score", response_model=InclusionResult, tags=["Inclusion"])
async def score_inclusion(
    request: InclusionInput,
    _: str = Depends(verify_api_key),
):
    """Score a decision for inclusion of informal, rural, women, youth, and disability actors."""
    return InclusionEngine.score(request)


# ─────────────────────────────────────────────────────────────
# 24HAE POLICY
# ─────────────────────────────────────────────────────────────

@app.post("/v1/24hae/evaluate", response_model=HaeResult, tags=["24HAE Policy"])
async def evaluate_24hae(
    request: HaeInput,
    _: str = Depends(verify_api_key),
):
    """Evaluate a decision against the 24-Hour Africa Economy Policy."""
    return HaeEngine.evaluate(request)


# ─────────────────────────────────────────────────────────────
# CORE DECISION — THE MAIN REASONING LOOP
# ─────────────────────────────────────────────────────────────

@app.post("/v1/decisions/resolve", tags=["Decisions"])
async def resolve_decision(
    request: DecisionRequest,
    _: str = Depends(verify_api_key),
):
    """
    🌍 AFRICA-OS Ω Core Endpoint

    Executes the full 19-step reasoning contract:
    Signal → Freshness → Source Reliability → Trail → Contradiction →
    Confidence → Inclusion → 24HAE Policy → Ecology → LLM Reasoning →
    Policy Postcheck → Local Fit → Escalation → Audit → Decision

    Returns a fully governed DecisionObject with audit trail.
    """
    if reasoning_loop is None:
        raise HTTPException(status_code=503, detail="Reasoning loop not initialised.")

    decision, escalation = await reasoning_loop.run(request)

    response = decision.model_dump(mode="json")
    if escalation:
        response["escalation"] = escalation.model_dump(mode="json")

    return response


# ─────────────────────────────────────────────────────────────
# ENTREPRENEUR INTELLIGENCE
# ─────────────────────────────────────────────────────────────

@app.post("/v1/entrepreneur/intelligence", tags=["Entrepreneur"])
async def entrepreneur_intelligence(
    sector: Sector,
    nation_id: str = "GH",
    query: str = "",
    business_type: str = "MSME",
    _: str = Depends(verify_api_key),
):
    """
    Simplified, actionable sector intelligence for MSMEs, startups, and cooperatives.
    The 24-hour economy must be accessible to entrepreneurs, not just institutions.
    """
    pack = get_sector_pack(sector)
    return {
        "sector": sector.value,
        "nation_id": nation_id,
        "business_type": business_type,
        "query": query,
        "sector_priority": pack.priority_24hae,
        "infrastructure_profile": pack.infrastructure_profile,
        "key_signal_types": list(pack.contradiction_tolerances.keys()),
        "applicable_laws": pack.jurisdiction_laws,
        "24hae_note": "Use /v1/decisions/resolve with entrepreneur role for full governed intelligence.",
        "tip": "Submit signals via /v1/signals/ingest using source_type=informal_operator for MSME data.",
    }


# ─────────────────────────────────────────────────────────────
# AUDIT
# ─────────────────────────────────────────────────────────────

@app.post("/v1/audit/replay", tags=["Audit"])
async def replay_audit(
    audit_ref: str,
    _: str = Depends(verify_api_key),
):
    """Replay a full reasoning chain by audit reference."""
    if audit_store is None:
        raise HTTPException(status_code=503, detail="Audit store not initialised.")
    record = await audit_store.replay(audit_ref)
    if not record:
        raise HTTPException(status_code=404, detail=f"Audit ref {audit_ref} not found.")
    return record


@app.get("/v1/audit/sector/{sector}", tags=["Audit"])
async def list_sector_audit(
    sector: str,
    date: str | None = None,
    _: str = Depends(verify_api_key),
):
    """List audit entries for a sector, optionally filtered by date (YYYY-MM-DD)."""
    if audit_store is None:
        raise HTTPException(status_code=503, detail="Audit store not initialised.")
    records = await audit_store.list_sector(sector, date)
    return {"sector": sector, "count": len(records), "entries": records[:50]}


# ─────────────────────────────────────────────────────────────
# SECTOR PACK INFO
# ─────────────────────────────────────────────────────────────

@app.get("/v1/sector-packs/{sector}", tags=["Sector Packs"])
async def get_sector_pack_info(
    sector: Sector,
    _: str = Depends(verify_api_key),
):
    """Retrieve the active configuration for a sector pack."""
    pack = get_sector_pack(sector)
    return {
        "sector_id": pack.sector_id.value,
        "sector_name": pack.sector_name,
        "priority_24hae": pack.priority_24hae,
        "lambda": pack.lambda_override,
        "half_life_hours": pack.half_life_hours,
        "domain_modifier": pack.domain_modifier,
        "confidence_threshold_trusted": pack.confidence_threshold_trusted,
        "contradiction_tolerances": pack.contradiction_tolerances,
        "ecology_active_metrics": pack.ecology_active_metrics,
        "eis_warning_threshold": pack.eis_warning_threshold,
        "eis_critical_threshold": pack.eis_critical_threshold,
        "jurisdiction_laws": pack.jurisdiction_laws,
        "infrastructure_profile": pack.infrastructure_profile,
        "escalation_rules": pack.escalation_rules,
    }
