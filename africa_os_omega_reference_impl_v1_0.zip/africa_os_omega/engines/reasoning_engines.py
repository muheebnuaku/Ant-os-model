"""
AFRICA-OS Ω — Reasoning Engines
==================================
Six engines that form the analytical core of the reasoning loop.
Each engine is a pure function: takes structured input, returns
a structured result with full traceability.

Engines:
  1. ConfidenceEngine       — weighted multivariate scoring with lambda decay
  2. ContradictionEngine    — signal conflict detection and severity grading
  3. EcologyEngine          — Ecology Impact Score (EIS) computation
  4. InclusionEngine        — inclusion scoring for underrepresented actors
  5. HaeEngine              — 24-Hour Africa Economy policy alignment
  6. LocalFitEngine         — contextual appropriateness for African deployment

Creator: Dr. David King Boison
"""

import math
import uuid
from typing import Optional

from models.schemas import (
    ConfidenceInput, ConfidenceResult, ValidationState,
    ContradictionResult, ContradictionSeverity,
    EcologyInput, EcologyResult, EisState,
    InclusionInput, InclusionResult,
    HaeInput, HaeResult, HaeState,
    LocalFitResult, Signal, Sector,
)
from core.sector_packs import get_sector_pack


# ─────────────────────────────────────────────────────────────
# ENGINE 1: CONFIDENCE CALIBRATION
# ─────────────────────────────────────────────────────────────

class ConfidenceEngine:
    """
    Computes confidence using a weighted multivariate formula with
    domain-specific calibration from the active sector pack.

    Formula:
    C = (W1*E) + (W2*F) + (W3*R) + (W4*X) + (W5*D) - (W6*P)

    Where:
      E = evidence_strength         (W1 = 0.28 default)
      F = signal_freshness          (W2 = 0.18 default)
      R = source_reliability        (W3 = 0.16 default)
      X = cross_signal_consistency  (W4 = 0.18 default)
      D = domain_stability_modifier (W5 = 0.10 default)
      P = contradiction_penalty     (W6 = 0.10 default)
    """

    @staticmethod
    def compute_freshness(age_hours: float, sector: Sector, signal_type: str = "default") -> tuple[float, float]:
        """
        Compute freshness using exponential decay: f = exp(-lambda * t)
        Returns (freshness, lambda_used)
        """
        pack = get_sector_pack(sector)
        lam = pack.lambda_override
        freshness = math.exp(-lam * age_hours)
        return round(max(0.0, min(1.0, freshness)), 4), lam

    @staticmethod
    def score(inp: ConfidenceInput) -> ConfidenceResult:
        pack = get_sector_pack(inp.sector)
        w = pack.weight_overrides

        raw = (
            w.evidence_strength         * inp.evidence_strength +
            w.signal_freshness          * inp.signal_freshness +
            w.source_reliability        * inp.source_reliability +
            w.cross_signal_consistency  * inp.cross_signal_consistency +
            w.domain_stability_modifier * inp.domain_stability_modifier -
            w.contradiction_penalty     * inp.contradiction_penalty
        )

        # Apply domain modifier
        adjusted = raw * pack.domain_modifier
        confidence = round(max(0.0, min(1.0, adjusted)), 4)

        # Map to validation state
        if confidence >= pack.confidence_threshold_trusted:
            state = ValidationState.TRUSTED
        elif confidence >= pack.confidence_threshold_provisional:
            state = ValidationState.PROVISIONAL
        elif confidence >= pack.confidence_threshold_conflicted:
            state = ValidationState.CONFLICTED
        else:
            state = ValidationState.BLOCKED

        return ConfidenceResult(
            confidence=confidence,
            validation_state=state,
            domain_modifier_applied=pack.domain_modifier,
            lambda_applied=pack.lambda_override,
            computation_ref=f"CONF-{uuid.uuid4().hex[:8].upper()}",
        )


# ─────────────────────────────────────────────────────────────
# ENGINE 2: CONTRADICTION GRAPH
# ─────────────────────────────────────────────────────────────

class ContradictionEngine:
    """
    Detects material conflicts between signals and assigns severity.

    Severity model: impact * confidence * domain_sensitivity
    Thresholds:
      minor    < 0.20 → downgrade confidence
      moderate < 0.50 → mark conflicted
      severe   ≥ 0.80 → block and escalate
    """

    SEVERITY_MINOR    = 0.20
    SEVERITY_MODERATE = 0.50
    SEVERITY_SEVERE   = 0.80

    @staticmethod
    def _get_tolerance(sector: Sector, signal_type: str) -> float:
        pack = get_sector_pack(sector)
        return pack.contradiction_tolerances.get(
            signal_type,
            pack.contradiction_tolerances.get("default", 0.15)
        )

    @classmethod
    def evaluate(cls, signals: list[Signal]) -> ContradictionResult:
        if len(signals) < 2:
            return ContradictionResult(
                contradiction_count=0,
                max_severity=0.0,
                severity_label=ContradictionSeverity.NONE,
                contradiction_penalty=0.0,
                recommended_action="proceed",
            )

        conflicts = []
        max_severity = 0.0

        # Compare numeric payloads across signal pairs
        for i in range(len(signals)):
            for j in range(i + 1, len(signals)):
                sig_a = signals[i]
                sig_b = signals[j]

                if sig_a.signal_type != sig_b.signal_type:
                    continue

                # Extract comparable numeric values
                val_a = cls._extract_numeric(sig_a.payload)
                val_b = cls._extract_numeric(sig_b.payload)

                if val_a is None or val_b is None:
                    continue

                tolerance = cls._get_tolerance(sig_a.sector, sig_a.signal_type)
                diff = abs(val_a - val_b)

                if diff > tolerance:
                    severity = min(1.0, diff * 2.0)  # normalised severity
                    max_severity = max(max_severity, severity)
                    conflicts.append({
                        "signal_a": sig_a.signal_id,
                        "signal_b": sig_b.signal_id,
                        "signal_type": sig_a.signal_type,
                        "difference": round(diff, 4),
                        "tolerance": tolerance,
                        "severity": round(severity, 4),
                    })

        # Grade severity
        if max_severity >= cls.SEVERITY_SEVERE:
            label  = ContradictionSeverity.SEVERE
            action = "block_and_escalate"
            penalty = 0.40
        elif max_severity >= cls.SEVERITY_MODERATE:
            label  = ContradictionSeverity.MODERATE
            action = "mark_conflicted"
            penalty = 0.20
        elif max_severity >= cls.SEVERITY_MINOR:
            label  = ContradictionSeverity.MINOR
            action = "downgrade_confidence"
            penalty = 0.10
        else:
            label  = ContradictionSeverity.NONE
            action = "proceed"
            penalty = 0.0

        return ContradictionResult(
            contradiction_count=len(conflicts),
            max_severity=round(max_severity, 4),
            severity_label=label,
            conflicted_signal_pairs=conflicts,
            contradiction_penalty=penalty,
            recommended_action=action,
        )

    @staticmethod
    def _extract_numeric(payload: dict) -> Optional[float]:
        """Extract first numeric value from payload for comparison."""
        for v in payload.values():
            if isinstance(v, (int, float)):
                return float(v)
        return None


# ─────────────────────────────────────────────────────────────
# ENGINE 3: ECOLOGY IMPACT SCORE
# ─────────────────────────────────────────────────────────────

class EcologyEngine:
    """
    Computes the Ecology Impact Score (EIS).

    Formula:
    EIS = (0.40 * environmental_impact) + (0.35 * social_impact) + (0.25 * resource_stress)

    Each component is a weighted mean of its five input variables.
    """

    ENV_WEIGHTS = {
        "carbon_emission_delta":         0.30,
        "land_use_change_risk":          0.25,
        "water_contamination_risk":      0.20,
        "biodiversity_disruption_index": 0.15,
        "waste_generation_level":        0.10,
    }
    SOC_WEIGHTS = {
        "community_displacement_risk": 0.25,
        "health_risk_to_population":   0.30,
        "equity_impact_score":         0.20,
        "cultural_heritage_risk":      0.10,
        "livelihood_disruption_index": 0.15,
    }
    RES_WEIGHTS = {
        "water_extraction_rate":       0.25,
        "energy_demand_stress":        0.20,
        "soil_degradation_index":      0.20,
        "infrastructure_load_factor":  0.20,
        "raw_material_depletion_risk": 0.15,
    }

    @classmethod
    def score(cls, inp: EcologyInput) -> EcologyResult:
        pack = get_sector_pack(inp.sector)

        env_score = cls._weighted_mean(inp.environmental_impact.model_dump(), cls.ENV_WEIGHTS)
        soc_score = cls._weighted_mean(inp.social_impact.model_dump(), cls.SOC_WEIGHTS)
        res_score = cls._weighted_mean(inp.resource_stress.model_dump(), cls.RES_WEIGHTS)

        eis = (0.40 * env_score) + (0.35 * soc_score) + (0.25 * res_score)
        eis = round(max(0.0, min(1.0, eis)), 4)

        if eis >= pack.eis_critical_threshold:
            state  = EisState.CRITICAL
            action = "block_if_irreversible_or_escalate"
        elif eis >= pack.eis_warning_threshold:
            state  = EisState.WARNING
            action = "modify_decision_and_flag"
        else:
            state  = EisState.ACCEPTABLE
            action = "allow_with_logging"

        return EcologyResult(
            eis_score=eis,
            eis_state=state,
            environmental_impact_score=round(env_score, 4),
            social_impact_score=round(soc_score, 4),
            resource_stress_score=round(res_score, 4),
            enforcement_action=action,
        )

    @staticmethod
    def _weighted_mean(values: dict, weights: dict) -> float:
        total = sum(values.get(k, 0.0) * w for k, w in weights.items())
        return total


# ─────────────────────────────────────────────────────────────
# ENGINE 4: INCLUSION ENGINE
# ─────────────────────────────────────────────────────────────

class InclusionEngine:
    """
    Scores decisions for their inclusion of underrepresented productive actors.
    The 24-hour economy must include informal, rural, women, youth, and
    persons with disability — not just formal institutional actors.
    """

    WEIGHTS = {
        "informal_economy_reach":     0.25,
        "rural_reach":                0.20,
        "gender_equity_score":        0.20,
        "youth_inclusion_score":      0.20,
        "disability_inclusion_score": 0.15,
    }
    PASS_THRESHOLD = 0.60

    @classmethod
    def score(cls, inp: InclusionInput) -> InclusionResult:
        values = inp.model_dump(exclude={"sector", "nation_id", "decision_ref"})
        weighted = sum(values.get(k, 0.0) * w for k, w in cls.WEIGHTS.items())
        inclusion_score = round(max(0.0, min(1.0, weighted)), 4)

        flagged = []
        adjustments = []

        for dim, weight in cls.WEIGHTS.items():
            val = values.get(dim, 0.0)
            if val < 0.40:
                flagged.append(dim)
                adjustments.append(
                    f"Improve {dim.replace('_', ' ')}: current score {val:.2f} is below 0.40 threshold."
                )

        state = "inclusive" if inclusion_score >= cls.PASS_THRESHOLD else "exclusionary"

        return InclusionResult(
            inclusion_score=inclusion_score,
            inclusion_state=state,
            flagged_dimensions=flagged,
            recommended_adjustments=adjustments,
        )


# ─────────────────────────────────────────────────────────────
# ENGINE 5: 24-HOUR AFRICA ECONOMY ALIGNMENT
# ─────────────────────────────────────────────────────────────

class HaeEngine:
    """
    Evaluates decisions against the 24-Hour Africa Economy Policy.

    Policy evaluation criteria:
    1. Does this sustain or increase productive capacity?
    2. Does this support intra-African value creation?
    3. Does this include informal and rural actors?
    4. Does this respect worker dignity and safety?
    5. Does this reduce dependency on external systems?
    6. Does this preserve sovereignty of data and thresholds?
    """

    @staticmethod
    def evaluate(inp: HaeInput) -> HaeResult:
        score = 0.0
        flags = []
        adjustments = []

        # 1. Productive capacity impact (weight: 0.35)
        # Maps [-1, 1] → [0, 1] contribution
        capacity_contribution = (inp.productive_capacity_impact + 1.0) / 2.0
        score += 0.35 * capacity_contribution
        if inp.productive_capacity_impact < 0:
            flags.append("REDUCES_PRODUCTIVE_CAPACITY")
            adjustments.append(
                "This decision reduces productive capacity. Evaluate whether short-term cost is "
                "offset by long-term 24HAE benefit."
            )

        # 2. Intra-African value creation (weight: 0.20)
        if inp.intra_african_value_creation:
            score += 0.20
        else:
            flags.append("NO_INTRA_AFRICAN_VALUE_CREATION")
            adjustments.append(
                "Consider whether intra-African sourcing, processing, or trade routes can "
                "replace or supplement external dependencies."
            )

        # 3. Informal actor inclusion (weight: 0.20)
        if inp.informal_actor_inclusion:
            score += 0.20
        else:
            flags.append("INFORMAL_ACTORS_EXCLUDED")
            adjustments.append(
                "The 24-hour economy requires inclusion of informal sector actors. "
                "Assess how this decision reaches informal operators."
            )

        # 4. Worker dignity (weight: 0.15)
        if inp.worker_dignity_preserved:
            score += 0.15
        else:
            flags.append("WORKER_DIGNITY_AT_RISK")
            adjustments.append(
                "CRITICAL: This decision may compromise worker dignity or safety. "
                "Review against labour guardrail before proceeding."
            )

        # 5. Dependency reduction (weight: 0.10)
        if inp.dependency_reduction:
            score += 0.10
        else:
            flags.append("DEPENDENCY_NOT_REDUCED")

        hae_score = round(max(0.0, min(1.0, score)), 4)

        if hae_score >= 0.75:
            state = HaeState.ALIGNED
        elif hae_score >= 0.50:
            state = HaeState.NEUTRAL
        elif hae_score >= 0.25:
            state = HaeState.MISALIGNED
        else:
            state = HaeState.CRITICAL

        return HaeResult(
            hae_alignment_score=hae_score,
            hae_state=state,
            policy_flags=flags,
            recommended_adjustments=adjustments,
        )


# ─────────────────────────────────────────────────────────────
# ENGINE 6: LOCAL FIT TEST
# ─────────────────────────────────────────────────────────────

class LocalFitEngine:
    """
    Validates that a decision is contextually appropriate for African deployment.

    Six dimensions — two are hard-fail (institutional_alignment, regulatory_grounding):
    any fail on these triggers escalation regardless of overall score.

    Pass threshold: ≥ 5 of 6 dimensions (≥ 0.833)
    """

    HARD_FAIL_DIMS = {"institutional_alignment", "regulatory_grounding"}
    PASS_THRESHOLD = 0.80

    @staticmethod
    def evaluate(
        sector: Sector,
        nation_id: str,
        has_valid_institution: bool = True,
        language_appropriate: bool = True,
        infrastructure_feasible: bool = True,
        culturally_safe: bool = True,
        regulatory_grounded: bool = True,
        resource_realistic: bool = True,
    ) -> LocalFitResult:

        dimensions = {
            "institutional_alignment":    has_valid_institution,
            "linguistic_appropriateness": language_appropriate,
            "infrastructure_feasibility": infrastructure_feasible,
            "cultural_safety":            culturally_safe,
            "regulatory_grounding":       regulatory_grounded,
            "resource_realism":           resource_realistic,
        }

        passed = [k for k, v in dimensions.items() if v]
        failed = [k for k, v in dimensions.items() if not v]
        score  = len(passed) / len(dimensions)
        hard_fail = any(d in LocalFitEngine.HARD_FAIL_DIMS for d in failed)
        passed_test = (score >= LocalFitEngine.PASS_THRESHOLD) and not hard_fail

        remediation = []
        for dim in failed:
            remediation_map = {
                "institutional_alignment":    "Update sector pack to reflect current institutional organogram.",
                "linguistic_appropriateness": "Add output localisation for target operator language.",
                "infrastructure_feasibility": "Add offline or async delivery pathway for this output type.",
                "cultural_safety":            "Add cultural context note to sector pack and re-run with cultural framing.",
                "regulatory_grounding":       "Update jurisdiction_laws in sector pack and recheck against current statutes.",
                "resource_realism":           "Add resource constraint parameters to sector pack and re-scope decision.",
            }
            remediation.append(remediation_map.get(dim, f"Review {dim}."))

        return LocalFitResult(
            local_fit_passed=passed_test,
            overall_score=round(score, 4),
            dimensions_evaluated=len(dimensions),
            dimensions_passed=len(passed),
            dimensions_failed=failed,
            hard_fail_triggered=hard_fail,
            escalation_triggered=hard_fail or not passed_test,
            recommended_remediation=remediation,
        )
