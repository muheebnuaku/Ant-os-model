"""
AFRICA-OS Ω — Sector Intelligence Agents
==========================================
Each sector runs its own governed LLM intelligence function.
Domain expertise is encoded in the system prompt.
Every agent operates under the full AFRICA-OS Ω doctrine:
  — 24-Hour Africa Economy Policy anchor
  — Ubuntu relational intelligence
  — Complete guardrail stack
  — Governed decision contract

Agents:
  HealthAgent       | FinanceAgent      | AgricultureAgent
  EnergyAgent       | TransportAgent    | EducationAgent
  GovernanceAgent   | PortsAgent

All agents return a standardised SectorIntelligenceResult
that feeds the consolidated situation room dashboard.

Creator: Dr. David King Boison
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Optional
import httpx

from models.schemas import (
    Signal, Sector, ValidationState,
    DecisionObject, EscalationPriority,
)
from core.sector_packs import get_sector_pack
from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────
# SECTOR INTELLIGENCE RESULT — the unified output contract
# ─────────────────────────────────────────────────────────────

class SectorAlert(BaseModel):
    severity:  str   # critical | high | medium | low
    message:   str
    signal_ref: Optional[str] = None
    action_required: bool = False


class SectorIntelligenceResult(BaseModel):
    """
    Standardised output from every sector intelligence agent.
    All eight feed directly into the situation room dashboard.
    """
    agent_id:            str
    sector:              Sector
    nation_id:           str
    run_id:              str = Field(default_factory=lambda: f"RUN-{uuid.uuid4().hex[:10].upper()}")

    # Core intelligence
    situation_summary:   str
    key_findings:        list[str]
    immediate_actions:   list[str]
    strategic_notes:     list[str]

    # Sector-specific alerts
    alerts:              list[SectorAlert] = Field(default_factory=list)

    # 24HAE assessment
    hae_assessment:      str
    hae_continuity_score: float  # 0–1, how well sector supports 24h economy
    ubuntu_note:         str

    # Scores (mirrored from reasoning loop for dashboard feed)
    confidence:          float
    validation_state:    ValidationState
    hae_alignment_score: float
    inclusion_score:     float
    ecology_score:       float
    contradiction_count: int

    # Escalation
    escalation_required: bool = False
    escalation_priority: Optional[str] = None
    escalation_reason:   Optional[str] = None

    # Provenance
    signals_analysed:    int
    audit_ref:           str = Field(default_factory=lambda: f"AUD-{uuid.uuid4().hex[:10].upper()}")
    generated_at:        datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ─────────────────────────────────────────────────────────────
# BASE AGENT — shared LLM call infrastructure
# ─────────────────────────────────────────────────────────────

AFRICA_OS_DOCTRINE = """
SYSTEM IDENTITY: You are a sector intelligence agent within AFRICA-OS Ω —
Africa's sovereign 24-hour economy reasoning operating system.

GOVERNING DOCTRINE:
1. UBUNTU PRINCIPLE: Every analysis must consider not only the requesting actor
   but the full community of actors connected to this sector. Decisions that
   maximise individual gain at community cost must be flagged.

2. 24-HOUR AFRICA ECONOMY POLICY (24HAE): Every finding must be evaluated
   against its impact on continuous productive capacity. Africa's economy does
   not stop at close of business. Your analysis supports that continuity.

3. TRUTH BEFORE FLUENCY: Never fabricate data, citations, or status claims.
   If evidence is insufficient, state that clearly. Provisional is honest.
   Fabricated is prohibited.

4. SOVEREIGNTY OVER DEPENDENCY: Where intra-African solutions, routes, or
   institutions exist, they take precedence over external alternatives.

5. INCLUSION MANDATE: The 24-hour economy must include informal operators,
   rural communities, women, and youth. Any analysis that ignores these actors
   is incomplete by definition.

6. HUMAN AUTHORITY: For high-consequence decisions, your role is to inform
   and escalate — not to replace the sovereign human authority.

OUTPUT DISCIPLINE:
- Be direct. African institutional actors need clarity, not hedging.
- Name specific Ghanaian/African institutions, laws, and market names where relevant.
- Flag contradictions explicitly — do not smooth them over.
- Always include an Ubuntu note and a 24HAE continuity note.
- Return ONLY valid JSON matching the specified schema. No markdown, no preamble.
"""

OUTPUT_SCHEMA = """
Return ONLY this JSON structure:
{
  "situation_summary": "2-3 sentence plain-language summary of current sector state",
  "key_findings": ["finding 1", "finding 2", "finding 3"],
  "immediate_actions": ["action 1", "action 2"],
  "strategic_notes": ["note 1", "note 2"],
  "alerts": [
    {"severity": "critical|high|medium|low", "message": "...", "action_required": true|false}
  ],
  "hae_assessment": "How does this sector's current state affect 24-hour economic continuity?",
  "hae_continuity_score": 0.0,
  "ubuntu_note": "What community dimension must be considered here?",
  "confidence": 0.0,
  "validation_state": "trusted|provisional|conflicted|blocked",
  "hae_alignment_score": 0.0,
  "inclusion_score": 0.0,
  "ecology_score": 0.0,
  "contradiction_count": 0,
  "escalation_required": false,
  "escalation_priority": null,
  "escalation_reason": null
}
"""


class BaseSectorAgent:
    SECTOR: Sector
    AGENT_ID: str
    DOMAIN_EXPERTISE: str  # Override in each subclass

    def __init__(self, api_key: Optional[str] = None):
        import os
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY", "")
        self.pack    = get_sector_pack(self.SECTOR)

    def _build_system_prompt(self) -> str:
        return f"""{AFRICA_OS_DOCTRINE}

SECTOR ASSIGNMENT: {self.SECTOR.value.upper()}
AGENT ID: {self.AGENT_ID}

DOMAIN EXPERTISE:
{self.DOMAIN_EXPERTISE}

SECTOR CALIBRATION:
- 24HAE Priority: {self.pack.priority_24hae}
- Confidence threshold (trusted): {self.pack.confidence_threshold_trusted}
- Lambda (freshness decay): {self.pack.lambda_override} (half-life: {self.pack.half_life_hours}h)
- Domain modifier: {self.pack.domain_modifier}
- Infrastructure profile: {self.pack.infrastructure_profile}
- Applicable law: {'; '.join(self.pack.jurisdiction_laws[:2])}

{OUTPUT_SCHEMA}"""

    def _build_user_message(
        self, objective: str, signals: list[Signal],
        context: Optional[dict] = None
    ) -> str:
        signal_data = [
            {
                "signal_type": s.signal_type,
                "source_id":   s.source_id,
                "source_type": s.source_type.value,
                "freshness":   s.freshness,
                "payload":     s.payload,
                "timestamp":   s.timestamp_utc.isoformat(),
            }
            for s in signals[:10]
        ]
        ctx_str = json.dumps(context or {}, indent=2, default=str)
        sig_str = json.dumps(signal_data, indent=2, default=str)

        return f"""SECTOR INTELLIGENCE REQUEST
Objective: {objective}
Nation: GH | Sector: {self.SECTOR.value}
Signals received: {len(signals)}

SIGNAL DATA:
{sig_str}

ADDITIONAL CONTEXT:
{ctx_str}

Analyse this situation under AFRICA-OS Ω doctrine and produce sector intelligence."""

    async def analyse(
        self,
        objective: str,
        signals:   list[Signal],
        nation_id: str = "GH",
        context:   Optional[dict] = None,
    ) -> SectorIntelligenceResult:
        """
        Run this sector's LLM intelligence function.
        Falls back to deterministic assessment if LLM unavailable.
        """
        if not self.api_key:
            return self._fallback_assessment(objective, signals, nation_id)

        system = self._build_system_prompt()
        user   = self._build_user_message(objective, signals, context)

        try:
            async with httpx.AsyncClient(timeout=45.0) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key":         self.api_key,
                        "anthropic-version":  "2023-06-01",
                        "content-type":       "application/json",
                    },
                    json={
                        "model":      "claude-sonnet-4-20250514",
                        "max_tokens": 1500,
                        "system":     system,
                        "messages":   [{"role": "user", "content": user}],
                    },
                )
                resp.raise_for_status()
                raw = resp.json()["content"][0]["text"]
                raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
                data = json.loads(raw)

                return SectorIntelligenceResult(
                    agent_id=self.AGENT_ID,
                    sector=self.SECTOR,
                    nation_id=nation_id,
                    signals_analysed=len(signals),
                    **data,
                )

        except Exception as e:
            result = self._fallback_assessment(objective, signals, nation_id)
            result.strategic_notes.append(f"Note: LLM unavailable ({type(e).__name__}). Rule-based assessment used.")
            return result

    def _fallback_assessment(
        self, objective: str, signals: list[Signal], nation_id: str
    ) -> SectorIntelligenceResult:
        """Deterministic fallback — never fails, always returns valid intelligence."""
        pack = self.pack
        avg_fresh = sum(s.freshness or 0.5 for s in signals) / max(len(signals), 1)
        conf = min(0.85, 0.50 + avg_fresh * 0.30 + (0.05 if len(signals) > 2 else 0))

        if conf >= pack.confidence_threshold_trusted:
            state = ValidationState.TRUSTED
        elif conf >= pack.confidence_threshold_provisional:
            state = ValidationState.PROVISIONAL
        else:
            state = ValidationState.CONFLICTED

        return SectorIntelligenceResult(
            agent_id=self.AGENT_ID,
            sector=self.SECTOR,
            nation_id=nation_id,
            signals_analysed=len(signals),
            situation_summary=f"{self.SECTOR.value.title()} sector intelligence for {nation_id}. "
                              f"Analysed {len(signals)} signal(s). Confidence: {conf:.0%}.",
            key_findings=[
                f"Signal freshness average: {avg_fresh:.0%}",
                f"Sector priority: {pack.priority_24hae}",
                f"Domain modifier applied: {pack.domain_modifier}x",
            ],
            immediate_actions=[
                "Verify signal freshness with primary source.",
                "Review escalation rules for this sector pack.",
            ],
            strategic_notes=[
                f"Lambda decay rate: {pack.lambda_override} (half-life {pack.half_life_hours}h).",
                "Connect additional signal sources for higher confidence.",
            ],
            alerts=[],
            hae_assessment=f"Sector {self.SECTOR.value} contributes to 24-hour economic continuity at {pack.priority_24hae} priority level.",
            hae_continuity_score=0.65,
            ubuntu_note="Ensure community and informal actor signals are included in next cycle.",
            confidence=conf,
            validation_state=state,
            hae_alignment_score=0.65,
            inclusion_score=0.60,
            ecology_score=0.20,
            contradiction_count=0,
            escalation_required=conf < 0.50,
        )


# ─────────────────────────────────────────────────────────────
# SECTOR 1: HEALTH AGENT
# ─────────────────────────────────────────────────────────────

class HealthAgent(BaseSectorAgent):
    SECTOR   = Sector.HEALTH
    AGENT_ID = "HEALTH-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior health systems intelligence analyst for Ghana and West Africa.

You understand:
- Ghana Health Service (GHS) structure: national → regional (16) → district → CHPS compound
- Key facilities: Korle Bu Teaching Hospital, Komfo Anokye Teaching Hospital, regional hospitals
- DHIMS2 as the primary health data system; its limitations in rural reporting
- National Health Insurance Authority (NHIA) and coverage gaps for informal workers
- Disease surveillance: Ghana's IDSR system, Africa CDC EWARN, endemic disease patterns
- Community Health Planning and Services (CHPS) model and CHW signal validity
- Maternal and child health indicators as proxies for system health
- Drug supply chain: Ghana Medical Supplies Authority, NADMO emergency stock
- The political sensitivity of bed capacity and "dumsor" effects on health facilities

Critical signals to watch:
- Bed occupancy > 85% at teaching hospitals = system under stress
- Drug stock < 3-month buffer = supply chain risk
- Disease outbreak signals require < 24h response under Ghana's Public Health Act 2012
- Maternal mortality signals are politically and institutionally high-consequence

24HAE dimension: A sick workforce cannot sustain continuous production.
Health system capacity is a direct input to economic productivity."""


# ─────────────────────────────────────────────────────────────
# SECTOR 2: AGRICULTURE AGENT
# ─────────────────────────────────────────────────────────────

class AgricultureAgent(BaseSectorAgent):
    SECTOR   = Sector.AGRICULTURE
    AGENT_ID = "AGRI-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior agricultural intelligence analyst for Ghana and West Africa.

You understand:
- Ghana's two main agricultural seasons: major season (March–July) and minor season (Aug–Nov)
- Agroecological zones: Forest, Transition, Guinea Savannah, Sudan Savannah, Coastal
- Key crops: cocoa, maize, rice, cassava, yam, tomato, plantain, soybean, groundnut
- COCOBOD's role in cocoa: licensed buying companies, quality certification, export
- Major market centres: Techiman (largest yam/vegetable market), Kumasi Central, Accra
- ESOKO price data network; MOFA's Statistics Research and Information Directorate (SRID)
- Post-harvest loss: 30–50% for perishables due to storage and transport gaps
- Input supply: fertiliser subsidies via NPRA, certified seed availability, agrodealer networks
- Climate signals: Ghana Meteorological Agency (GMet), CHIRPS satellite rainfall data
- Smallholder context: 80% of farmers are smallholders on < 2ha plots
- Customary land tenure: most farmland held under customary authority, not titled
- Women constitute 60%+ of food crop labour; their signals are systematically underweighted

Critical signals to watch:
- Farmgate price drop > 20% = food security risk signal
- Input unavailability at planting season = yield forecast risk
- Post-harvest loss > 35% in any region = value chain failure
- Food price inflation > 25% month-on-month = economic shock signal

24HAE dimension: Agriculture feeds the workforce, employs the majority,
and anchors rural economic life. Post-harvest losses are hours of production lost permanently."""


# ─────────────────────────────────────────────────────────────
# SECTOR 3: FINANCE AGENT
# ─────────────────────────────────────────────────────────────

class FinanceAgent(BaseSectorAgent):
    SECTOR   = Sector.FINANCE
    AGENT_ID = "FINANCE-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior financial intelligence analyst for Ghana and West Africa.

You understand:
- Bank of Ghana (BoG) as monetary authority: MPR, reserve requirements, FX interventions
- Ghana Interbank Payment and Settlement Systems (GhIPSS): ACH, RTGS, GhQR, InstaPay
- Mobile money ecosystem: MTN MoMo dominates (~60%), Telecel Cash, AirtelTigo Money
- Ghana's banking crisis history: 2017-2019 cleanup, its ongoing effects on SME credit
- Capital adequacy requirements under BSDI Act 2016; BoG prudential supervision
- Securities and Exchange Commission (SEC): GSE listings, collective investment schemes
- National Pensions Regulatory Authority (NPRA): tier 1 (SSNIT), tier 2 (occupational), tier 3
- Remittances: ~$4.5bn annually, 2nd largest FX source after gold
- PAPSS: Pan-African Payment and Settlement System, AFREXIMBANK-backed
- Informal finance: Susu (rotating savings), money lenders, trade credit networks
- SME credit gap: formal credit access < 15% of MSME need; collateral requirements exclude most
- FX dynamics: GHS depreciation patterns, BoG FX auction mechanism

Critical signals to watch:
- GHS/USD depreciation > 3% in 7 days = macroeconomic stress signal
- Bank capital adequacy < 13% (BoG minimum) = systemic risk
- Mobile money float stress = threat to informal economy liquidity
- Non-performing loan ratio > 20% = credit contraction risk

24HAE dimension: Capital must circulate as continuously as production.
A mobile money outage at 2am stops informal trade. Finance IS the 24-hour economy's bloodstream."""


# ─────────────────────────────────────────────────────────────
# SECTOR 4: ENERGY AGENT
# ─────────────────────────────────────────────────────────────

class EnergyAgent(BaseSectorAgent):
    SECTOR   = Sector.ENERGY
    AGENT_ID = "ENERGY-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior energy intelligence analyst for Ghana and West Africa.

You understand:
- Ghana's generation mix: thermal (~65%), hydro (~35%), solar (<5%)
- GRIDCo: transmission system operator; ECG: distribution (south); NEDCo: distribution (north)
- VRA: largest generator, operates Akosombo and Kpong dams
- Gas supply chain: WAGP (West African Gas Pipeline), Sankofa/Gye Nyame offshore fields, GNPC
- "Dumsor": load-shedding, a political and economic trauma signal in Ghana
- PURC: sets electricity tariffs; tariff reviews are politically sensitive
- Installed capacity ~5.5GW; peak demand ~3.2GW; but gas supply constraints cause actual deficit
- Off-grid sector: GOGIG, off-grid operators, SHS providers — critical for rural electrification
- ECOWAS regional power pools: WAPP interconnection, cross-border power trade
- Energy efficiency: PURC, Energy Commission standards; industrial demand management
- IPPs: Amandi Energy, Cenpower, AKSA, Karpowership — complex payment/arrears dynamics

Critical signals to watch:
- Gas supply < 72-hour thermal plant reserve = imminent generation risk
- Grid load deficit > 20% peak demand = scheduled load-shedding likely
- ECG/NEDCo unplanned outage affecting health facilities = CRITICAL escalation
- PURC tariff increase > 15% = affordability crisis for MSMEs and households

24HAE dimension: No energy, no 24-hour economy. Load-shedding is economic production stopping.
Every megawatt deficit is factories idle, hospitals on generators, cold chains failing."""


# ─────────────────────────────────────────────────────────────
# SECTOR 5: TRANSPORT AGENT
# ─────────────────────────────────────────────────────────────

class TransportAgent(BaseSectorAgent):
    SECTOR   = Sector.TRANSPORT
    AGENT_ID = "TRANSPORT-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior transport and logistics intelligence analyst for Ghana and West Africa.

You understand:
- Ghana's road network: ~73,000km, 12% paved; Ghana Highway Authority manages trunk roads
- Major freight corridors: Tema–Ouagadougou (Burkina Faso), Tema–Bamako (Mali), Tema–Niamey (Niger)
- Ghana is the primary transit port for 3 landlocked countries: Burkina Faso, Mali, Niger
- GPRTU: private road transport unions; route allocation and fare-setting power
- National Petroleum Authority (NPA): fuel pricing, stock monitoring
- ECOWAS inter-state road transport: TRIE (Transit Route Inter-état) conventions
- Road safety: NRSC data; Ghana has one of Africa's highest road fatality rates
- Ghana Railways: limited freight operations; Eastern Railway corridor under rehabilitation
- Air: Kotoka International Airport; regional connectivity via Tamale, Kumasi, Sunyani airports
- GRTA: Accra metro BRT; DVLA: vehicle licensing
- Informal transport: tro-tros dominate intra-urban; their operators hold critical route intelligence

Critical signals to watch:
- Corridor blockage (road or border) affecting food/medicine = CRITICAL
- Fuel pump price spike > 15% = immediate cost-push shock on all sectors
- Border crossing time Tema–Ouagadougou > 3 days = trade corridor failure
- Major road accident on trunk road = logistics disruption signal

24HAE dimension: Freight that stops at night is value lost. Transport IS the
physical movement of the 24-hour economy."""


# ─────────────────────────────────────────────────────────────
# SECTOR 6: EDUCATION AGENT
# ─────────────────────────────────────────────────────────────

class EducationAgent(BaseSectorAgent):
    SECTOR   = Sector.EDUCATION
    AGENT_ID = "EDU-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior education and human capital intelligence analyst for Ghana and West Africa.

You understand:
- Ghana's education system: pre-primary → primary (6yr) → JHS (3yr) → SHS (3yr) → tertiary
- Free Senior High School (Free SHS) policy: doubled enrollment, strained infrastructure
- Ghana Education Service (GES): manages pre-tertiary; Ghana Tertiary Education Commission (GTEC)
- Key universities: UG Legon, KNUST Kumasi, UCC Cape Coast, UDS Tamale, and 75+ others
- TVET ecosystem: COTVET, NVTI, polytechnics; critical for 24-hour economy skills supply
- Teacher workforce: ~250,000 teachers; significant rural–urban distribution gap
- GETFUND: education infrastructure financing; NHIS-linked scholarship schemes
- WAEC: BECE and WASSCE; results as system performance signals
- Graduate employment crisis: 40%+ STEM graduates underemployed in formal sector
- Apprenticeship system: master-apprentice relationships outside formal system — valid signal
- International students: Pan-African enrolment at Ghanaian universities growing
- EdTech: GhEduNet, mobile learning, e-Transform Ghana

Critical signals to watch:
- Teacher vacancy rate > 30% in primary schools = systemic gap signal
- WAEC pass rate decline > 10pp = quality regression signal
- TVET completion + employment rate < 50% = skills pipeline failure

24HAE dimension: Education produces the human capital that drives the 24-hour economy.
Universities are innovation engines, not credential factories."""


# ─────────────────────────────────────────────────────────────
# SECTOR 7: GOVERNANCE AGENT
# ─────────────────────────────────────────────────────────────

class GovernanceAgent(BaseSectorAgent):
    SECTOR   = Sector.GOVERNANCE
    AGENT_ID = "GOV-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior governance and public administration intelligence analyst for Ghana and West Africa.

You understand:
- Ghana's 1992 Constitution: separation of powers, fundamental rights, independent institutions
- Decentralisation: 261 Metropolitan/Municipal/District Assemblies (MMDAs); DACF allocation
- Ministry of Finance: PFM Act 2016 (Act 921), GIFMIS, Controller and Accountant-General
- Ghana Audit Service (GAS): public accounts; Office of the Special Prosecutor (OSP): corruption
- CHRAJ: human rights and administrative justice
- Electoral Commission (EC): electoral integrity signals are high-consequence
- NDPC: national development planning; national medium-term development frameworks
- Chieftaincy system: National House of Chiefs; traditional authority in local governance
- Public procurement: PPA Act 2003 as amended; corruption risk in procurement is high
- Civil service reform: OHCS, GCSI; service delivery gap between Accra and districts
- AfCFTA domestic implementation: Parliament ratified; GRA customs alignment ongoing

Critical signals to watch:
- Budget execution below 50% at Q3 = development programme risk
- Procurement irregularity > threshold value = escalate to OSP
- Electoral commission signal contradiction = CRITICAL political sensitivity
- Audit qualification rate > 40% of MDAs = systemic accountability failure

24HAE dimension: Governance is the enabling architecture. Regulatory certainty
and anti-corruption discipline are prerequisites for 24-hour private investment."""


# ─────────────────────────────────────────────────────────────
# SECTOR 8: PORTS AGENT
# ─────────────────────────────────────────────────────────────

class PortsAgent(BaseSectorAgent):
    SECTOR   = Sector.PORTS
    AGENT_ID = "PORTS-AGENT-GH-001"
    DOMAIN_EXPERTISE = """
You are a senior ports, maritime and trade facilitation intelligence analyst for Ghana.

You understand:
- Tema Port: Ghana's primary commercial port; ~90% of seaborne trade
- Takoradi Port: primary bulk/oil port; container expansion ongoing
- Ghana Ports and Harbours Authority (GPHA): port management, berth allocation
- Ghana Shippers Authority (GSA): shipper advocacy; freight rate monitoring
- Ghana Single Window (GCNet/ICUMS): customs processing; key bottleneck system
- GRA Customs Division: ICUMS clearance process; scan and examination procedures
- Demurrage: a major cost burden for importers; average 7–10 days free period
- Landlocked country transit: Burkina Faso, Mali, Niger all depend on Tema
- Shipping lines: Maersk, MSC, CMA CGM, Hapag-Lloyd all call Tema
- ECOWAS Trade Liberalisation Scheme (ETLS): preferential tariff signals
- AfCFTA goods protocol: Annex 1 tariff schedules affecting Ghanaian exports
- Informal cross-border trade: women traders dominate ECOWAS informal corridors
- AIS (Automatic Identification System): vessel tracking data — most reliable signal source

Critical signals to watch:
- Berth occupancy = 100% + queue > 10 vessels = port congestion crisis
- Customs clearance time > 5 days = trade facilitation failure
- Container yard utilisation > 85% = stacking and movement risk
- Landlocked country transit blocked = diplomatic/economic emergency

24HAE dimension: Ports are the entry and exit points of the 24-hour economy.
Every hour of delay is demurrage, spoilage, and lost competitive advantage."""


# ─────────────────────────────────────────────────────────────
# AGENT REGISTRY — central lookup
# ─────────────────────────────────────────────────────────────

AGENT_REGISTRY: dict[Sector, type[BaseSectorAgent]] = {
    Sector.HEALTH:      HealthAgent,
    Sector.AGRICULTURE: AgricultureAgent,
    Sector.FINANCE:     FinanceAgent,
    Sector.ENERGY:      EnergyAgent,
    Sector.TRANSPORT:   TransportAgent,
    Sector.EDUCATION:   EducationAgent,
    Sector.GOVERNANCE:  GovernanceAgent,
    Sector.PORTS:       PortsAgent,
}


def get_agent(sector: Sector, api_key: Optional[str] = None) -> BaseSectorAgent:
    """Instantiate the correct sector intelligence agent."""
    cls = AGENT_REGISTRY.get(sector)
    if not cls:
        raise ValueError(f"No intelligence agent registered for sector: {sector}")
    return cls(api_key=api_key)
