"""
AFRICA-OS Ω — FastAPI Application v1.1
========================================
Africa's Intelligence System OS.
Eight sector intelligence agents, one sovereign view.

New in v1.1:
  POST /v1/intelligence/{sector}          — single sector agent
  POST /v1/intelligence/situation-room    — all 8 agents parallel
  GET  /v1/intelligence/dashboard-feed    — live dashboard payload

Creator: Dr. David King Boison
"""

import os, time, math
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import (
    SignalIngestRequest, SignalIngestResponse,
    ConfidenceInput, ConfidenceResult,
    EcologyInput, EcologyResult,
    InclusionInput, InclusionResult,
    HaeInput, HaeResult,
    DecisionRequest,
    Sector, Signal, SourceType,
)
from engines.reasoning_engines import (
    ConfidenceEngine, ContradictionEngine,
    EcologyEngine, InclusionEngine, HaeEngine,
)
from engines.sector_agents import get_agent, AGENT_REGISTRY
from engines.orchestrator import AgentOrchestrator
from core.reasoning_loop import ReasoningLoop
from core.audit import AuditStore
from core.sector_packs import get_sector_pack


# ── GLOBALS ──────────────────────────────────────────────────
audit_store:      AuditStore        = None
reasoning_loop:   ReasoningLoop     = None
orchestrator:     AgentOrchestrator = None
_dashboard_cache: dict              = {}
_cache_ts:        datetime          = None
CACHE_TTL = 120   # seconds


@asynccontextmanager
async def lifespan(app: FastAPI):
    global audit_store, reasoning_loop, orchestrator
    api_key        = os.getenv("ANTHROPIC_API_KEY", "")
    log_path       = os.getenv("AUDIT_LOG_PATH", "./audit_logs")
    audit_store    = AuditStore(log_path=log_path)
    reasoning_loop = ReasoningLoop(audit_store=audit_store)
    orchestrator   = AgentOrchestrator(api_key=api_key)
    print("✅  AFRICA-OS Ω v1.1 — Africa Intelligence System OS")
    print(f"✅  {len(AGENT_REGISTRY)} sector intelligence agents loaded")
    print(f"✅  LLM: {'Anthropic Claude' if api_key else 'Rule-based fallback'}")
    print("🌍  Always on. Always governed. Always African.\n")
    yield


app = FastAPI(
    title="AFRICA-OS Ω — Africa Intelligence System OS",
    description="Eight sector intelligence agents governed by the 24-Hour Africa Economy Policy. Creator: Dr. David King Boison.",
    version="1.1.0",
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

API_KEY = os.getenv("API_KEY", "africa-os-dev-key")

@app.middleware("http")
async def timing(request: Request, call_next):
    t = time.time()
    r = await call_next(request)
    r.headers["X-AFRICAOS-Latency-ms"] = str(round((time.time()-t)*1000, 1))
    r.headers["X-AFRICAOS-Version"]    = "1.1.0"
    return r

def auth(x_api_key: str = Header(default="africa-os-dev-key")):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Invalid API key.")
    return x_api_key


# ── ROOT ─────────────────────────────────────────────────────
@app.get("/", tags=["System"])
async def root():
    return {
        "system": "AFRICA-OS Ω — Africa Intelligence System OS",
        "version": "1.1.0",
        "creator": "Dr. David King Boison",
        "anchor_policy": "24-Hour Africa Economy Policy",
        "epistemic_root": "Ubuntu — I am because we are",
        "active_sectors": [s.value for s in Sector],
        "intelligence_agents": len(AGENT_REGISTRY),
        "status": "operational",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/health", tags=["System"])
async def health():
    return {"status": "healthy", "agents": len(AGENT_REGISTRY), "timestamp_utc": datetime.now(timezone.utc).isoformat()}


# ── ★ SECTOR INTELLIGENCE AGENTS ─────────────────────────────

@app.post("/v1/intelligence/{sector}", tags=["Intelligence Agents"])
async def sector_intelligence(
    sector: Sector,
    objective: str,
    signals: list[SignalIngestRequest],
    nation_id: str = "GH",
    _: str = Depends(auth),
):
    """Run the sector intelligence agent — domain expertise + 24HAE + Ubuntu + guardrails."""
    if not orchestrator:
        raise HTTPException(503, "Orchestrator not initialised.")
    sig_objects = [
        Signal(signal_type=s.signal_type, source_id=s.source_id, source_type=s.source_type,
               sector=sector, nation_id=nation_id, payload=s.payload, freshness=0.90, age_hours=0.1)
        for s in signals
    ]
    result = await orchestrator.run_sector(sector, objective, sig_objects, nation_id)
    return result.model_dump(mode="json")


@app.post("/v1/intelligence/situation-room", tags=["Intelligence Agents"])
async def situation_room(
    nation_id: str = "GH",
    sectors: list[Sector] = None,
    _: str = Depends(auth),
):
    """Run all 8 sector agents in parallel — consolidated SituationBrief for the dashboard."""
    if not orchestrator:
        raise HTTPException(503, "Orchestrator not initialised.")
    brief = await orchestrator.run_situation_room(nation_id=nation_id, sectors=sectors)
    global _dashboard_cache, _cache_ts
    _dashboard_cache = brief.model_dump(mode="json")
    _cache_ts = datetime.now(timezone.utc)
    return _dashboard_cache


@app.get("/v1/intelligence/dashboard-feed", tags=["Intelligence Agents"])
async def dashboard_feed(
    nation_id: str = "GH",
    force_refresh: bool = False,
    _: str = Depends(auth),
):
    """Live dashboard feed — cached 120s, or force a fresh run."""
    global _dashboard_cache, _cache_ts
    now = datetime.now(timezone.utc)
    age = (now - _cache_ts).total_seconds() if _cache_ts else 999
    if force_refresh or not _dashboard_cache or age > CACHE_TTL:
        if not orchestrator:
            raise HTTPException(503, "Orchestrator not initialised.")
        brief = await orchestrator.run_situation_room(nation_id=nation_id)
        _dashboard_cache = brief.model_dump(mode="json")
        _cache_ts = now
        age = 0
    return {**_dashboard_cache, "_meta": {"cache_age_seconds": round(age, 1), "served_at": now.isoformat()}}


# ── SIGNALS ──────────────────────────────────────────────────
@app.post("/v1/signals/ingest", response_model=SignalIngestResponse, tags=["Signals"])
async def ingest_signal(req: SignalIngestRequest, _: str = Depends(auth)):
    pack = get_sector_pack(req.sector)
    sig  = Signal(signal_type=req.signal_type, source_id=req.source_id, source_type=req.source_type,
                  sector=req.sector, nation_id=req.nation_id, payload=req.payload,
                  timestamp_utc=datetime.now(timezone.utc))
    fresh = round(math.exp(-pack.lambda_override * 0), 4)
    return SignalIngestResponse(accepted=True, signal_ref=sig.signal_id,
                                freshness_at_ingest=fresh,
                                validation_note=f"λ={pack.lambda_override}, t½={pack.half_life_hours}h.")


# ── CONFIDENCE ───────────────────────────────────────────────
@app.post("/v1/confidence/score", response_model=ConfidenceResult, tags=["Confidence"])
async def score_confidence(req: ConfidenceInput, _: str = Depends(auth)):
    return ConfidenceEngine.score(req)

@app.post("/v1/confidence/freshness", tags=["Confidence"])
async def freshness(sector: Sector, signal_type: str = "default", age_hours: float = 0.0, _: str = Depends(auth)):
    pack = get_sector_pack(sector)
    f, lam = ConfidenceEngine.compute_freshness(age_hours, sector, signal_type)
    return {"freshness": f, "lambda_used": lam, "half_life_hours": pack.half_life_hours}


# ── CONTRADICTIONS ───────────────────────────────────────────
@app.post("/v1/contradictions/evaluate", tags=["Contradictions"])
async def contradictions(signals: list[SignalIngestRequest], sector: Sector,
                         nation_id: str = "GH", _: str = Depends(auth)):
    sigs = [Signal(signal_type=s.signal_type, source_id=s.source_id, source_type=s.source_type,
                   sector=sector, nation_id=nation_id, payload=s.payload,
                   timestamp_utc=datetime.now(timezone.utc)) for s in signals]
    return ContradictionEngine.evaluate(sigs)


# ── ECOLOGY / INCLUSION / 24HAE ───────────────────────────────
@app.post("/v1/ecology/score",    response_model=EcologyResult,   tags=["Ecology"])
async def ecology(req: EcologyInput,   _: str = Depends(auth)): return EcologyEngine.score(req)

@app.post("/v1/inclusion/score",  response_model=InclusionResult, tags=["Inclusion"])
async def inclusion(req: InclusionInput, _: str = Depends(auth)): return InclusionEngine.score(req)

@app.post("/v1/24hae/evaluate",   response_model=HaeResult,       tags=["24HAE Policy"])
async def hae(req: HaeInput,         _: str = Depends(auth)): return HaeEngine.evaluate(req)


# ── DECISIONS ────────────────────────────────────────────────
@app.post("/v1/decisions/resolve", tags=["Decisions"])
async def resolve(req: DecisionRequest, _: str = Depends(auth)):
    """Full 19-step reasoning contract."""
    if not reasoning_loop:
        raise HTTPException(503, "Reasoning loop not initialised.")
    decision, escalation = await reasoning_loop.run(req)
    resp = decision.model_dump(mode="json")
    if escalation:
        resp["escalation"] = escalation.model_dump(mode="json")
    return resp


# ── AUDIT ────────────────────────────────────────────────────
@app.post("/v1/audit/replay", tags=["Audit"])
async def replay(audit_ref: str, _: str = Depends(auth)):
    rec = await audit_store.replay(audit_ref)
    if not rec:
        raise HTTPException(404, f"Audit ref {audit_ref} not found.")
    return rec

@app.get("/v1/audit/sector/{sector}", tags=["Audit"])
async def audit_sector(sector: str, date: str = None, _: str = Depends(auth)):
    recs = await audit_store.list_sector(sector, date)
    return {"sector": sector, "count": len(recs), "entries": recs[:50]}


# ── SECTOR PACKS ─────────────────────────────────────────────
@app.get("/v1/sector-packs/{sector}", tags=["Sector Packs"])
async def sector_pack_info(sector: Sector, _: str = Depends(auth)):
    p = get_sector_pack(sector)
    return {"sector_id": p.sector_id.value, "sector_name": p.sector_name,
            "priority_24hae": p.priority_24hae, "lambda": p.lambda_override,
            "half_life_hours": p.half_life_hours, "domain_modifier": p.domain_modifier,
            "confidence_threshold_trusted": p.confidence_threshold_trusted,
            "jurisdiction_laws": p.jurisdiction_laws,
            "infrastructure_profile": p.infrastructure_profile}
